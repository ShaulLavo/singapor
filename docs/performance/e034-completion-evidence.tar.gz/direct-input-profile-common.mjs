import { writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { fail } from './benchmark-worktree/examples/stress/errors.mjs'

const BEFORE = 'e034-profile-beforeinput'
const APPLIED = 'e034-profile-onChange'

export function instrumentInputEvents(source) {
  const replacements = [
    ['function beginEditBurst() {', `function beginEditBurst() {
  performance.clearMarks('${BEFORE}')
  performance.clearMarks('${APPLIED}')`],
    ['  inputMeasurements.push({ at: performance.now(), appliedAt: null, frameAt: null })', `  inputMeasurements.push({ at: performance.now(), appliedAt: null, frameAt: null })
  performance.mark('${BEFORE}', {
    startTime: inputMeasurements.at(-1)!.at,
    detail: { index: inputMeasurements.length - 1, trusted: event.isTrusted },
  })`],
    ['  input.appliedAt = performance.now()', `  input.appliedAt = performance.now()
  performance.mark('${APPLIED}', {
    startTime: input.appliedAt,
    detail: { index: inputMeasurements.length - 1 },
  })`],
    ['  finishEditBurst,', `  finishEditBurst,
  profileInputObservation: () => ({
    events: inputMeasurements.map((input) => ({ ...input })),
    marks: performance.getEntriesByType('mark')
      .filter((entry) => entry.name.startsWith('e034-profile-'))
      .map((entry) => ({ name: entry.name, at: entry.startTime, detail: (entry as PerformanceMark).detail })),
  }),`],
  ]
  let transformed = source
  for (const [before, after] of replacements) {
    if (transformed.split(before).length !== 2) fail(`Input profile transform mismatch: ${before}`)
    transformed = transformed.replace(before, after)
  }
  return transformed
}

export async function profileClock(page, cdp) {
  await cdp.send('Performance.enable')
  const beforeMs = await page.evaluate(() => performance.now())
  const { metrics } = await cdp.send('Performance.getMetrics')
  const afterMs = await page.evaluate(() => performance.now())
  const values = Object.fromEntries(metrics.map(({ name, value }) => [name, value]))
  const navigationStartMicros = values.NavigationStart * 1_000_000
  const metricNowMs = (values.Timestamp - values.NavigationStart) * 1000
  if (!Number.isFinite(navigationStartMicros) || navigationStartMicros <= 0)
    fail('Missing CDP navigation clock origin')
  if (!Number.isFinite(metricNowMs) || metricNowMs < beforeMs - 0.25 || metricNowMs > afterMs + 0.25)
    fail('CDP NavigationStart and browser performance.now clocks do not align')
  return { navigationStartMicros, beforeMs, metricNowMs, afterMs, validationToleranceMs: 0.25 }
}

export async function saveInputProfile(directory, name, profile, observation, clock) {
  const { events, marks } = observation
  if (events.length !== 12 || marks.length !== 24) fail('Missing real input event marks')
  const before = marks.filter((mark) => mark.name === BEFORE)
  const applied = marks.filter((mark) => mark.name === APPLIED)
  if (before.length !== 12 || applied.length !== 12) fail('Missing input boundary marks')
  if (!profile.samples || profile.samples.length !== profile.timeDeltas?.length)
    fail('CPU profile lacks sample timestamps')
  let time = profile.startTime
  const samples = profile.samples.map((nodeId, index) => {
    time += profile.timeDeltas[index]
    return { index, nodeId, atMicros: time }
  })
  const windows = events.map((event, index) => {
    if (before[index].detail.index !== index || before[index].detail.trusted !== true ||
        applied[index].detail.index !== index || before[index].at !== event.at ||
        applied[index].at !== event.appliedAt || !Number.isFinite(event.appliedAt) ||
        !Number.isFinite(event.frameAt) || event.appliedAt < event.at || event.frameAt < event.appliedAt)
      fail('Input marks do not match trusted beforeinput/onChange observations')
    const startMicros = clock.navigationStartMicros + event.at * 1000
    const endMicros = clock.navigationStartMicros + event.appliedAt * 1000
    if (startMicros < profile.startTime - 250 || endMicros > profile.endTime + 250)
      fail('Input event falls outside the CPU profile clock window')
    return {
      index, startMicros, endMicros, latencyMs: event.appliedAt - event.at,
      samples: samples.filter((sample) => sample.atMicros >= startMicros && sample.atMicros < endMicros),
    }
  })
  const evidence = {
    schemaVersion: 1, budgetEligible: false, timingComparable: false,
    window: 'trusted-beforeinput-through-public-onChange; half-open sample timestamp selection',
    sampleWeights: 'not estimated; selected node IDs refer to the untouched CPU profile',
    allocationBytes: null,
    clock, events, marks, windows,
    nonMonotonicSampleDeltas: profile.timeDeltas.filter((delta) => delta < 0).length,
    limits: [
      '100us sampled stacks are diagnostic and are not production latency measurements.',
      'User Timing marks add work inside input; both arms use identical instrumentation.',
      'finishEditBurst runs after Profiler.stop, but later GC can collect allocations made before the profile.',
      'CPU samples do not identify allocated bytes or establish an Editor allocation regression.',
      'Boundary attribution is limited by browser timestamp quantization and CPU sampling.',
    ],
  }
  await writeFile(resolve(directory, `${name}.cpuprofile`), JSON.stringify(profile) + '\n')
  await writeFile(resolve(directory, `${name}.events.json`), JSON.stringify(evidence) + '\n')
  return { cpuProfile: `${name}.cpuprofile`, inputProfileEvents: `${name}.events.json` }
}
