# Aborted completion experiment

The original `final-design.json` was declared before capture and remains unchanged. The experiment
started on 2026-09-12 at 16:07 UTC. It used the frozen `candidate-optimized` core, before the later
subtree, marker-batching and input-buffer changes.

Ten complete blocks produced 30 captures. Block 11 then produced its control capture. The next
baseline run failed before document capture at 16:44:43 UTC, when the runner hashed a temporary
Chromium directory that disappeared during traversal. The failed run produced no result JSON.
All 31 successful captures, the failed log, screenshots and the timeline are retained under `final/`.
The absence of the last five records means this declaration cannot pass final validation.

`aborted-analysis-design.json` explicitly classifies the ten complete blocks as a pilot. Their
paired analysis is in `aborted-analysis.json`. The extra block-11 control is preserved but cannot
form a paired block. All eight primary upper bounds remain positive; these records establish
neither final acceptance nor a demonstrated regression. No control drift was detected.

The runner now separates Vite output and Chromium temporary files into sibling directories.
`runner-repair-baseline.json` verifies the repaired runner against the frozen baseline with the
same core and browser-bundle hashes as the earlier captures. The later acceptance declaration
uses only new captures of its own frozen candidate. No earlier sample enters that comparison.
