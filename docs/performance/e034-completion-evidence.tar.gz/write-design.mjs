import { writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { primaryMetrics, secondaryMetrics } from './analysis.mjs'

const output = resolve(process.argv[2] ?? '/work/tmp/editor-e034-completion/final-design.json')
const directory = resolve(process.argv[3] ?? '/work/tmp/editor-e034-completion/final')
const orders = [
  ['baseline', 'control', 'candidate'], ['control', 'candidate', 'baseline'], ['candidate', 'baseline', 'control'],
  ['candidate', 'control', 'baseline'], ['control', 'baseline', 'candidate'], ['baseline', 'candidate', 'control'],
]
const design = {
  schemaVersion: 1, purpose: 'final', predeclaredAt: new Date().toISOString(),
  seed: 60061, bootstrapDraws: 32768, familywiseAlpha: 0.05,
  clockQuantumMs: 0.1, numericalEpsilonMs: 1e-7, regressionMarginMs: 0,
  primaryMetrics, secondaryMetrics,
  blocks: Array.from({ length: 12 }, (_, index) => {
    const id = `block-${String(index + 1).padStart(2, '0')}`
    return { id, order: orders[index % orders.length], ...Object.fromEntries(['baseline', 'control', 'candidate'].map((arm) => [arm, resolve(directory, `${id}-${arm}.json`)])) }
  }),
}
await writeFile(output, JSON.stringify(design, null, 2) + '\n', { flag: 'wx' })
console.log(output)
