import json
from collections import defaultdict
from pathlib import Path
import sys
root=Path(sys.argv[1])
sums={field:defaultdict(float) for field in ['self','inclusive']}
profiles=[]
for line in (root/'summary-all.jsonl').read_text().splitlines():
    record=json.loads(line)
    profiles.append({key:record[key] for key in ['file','durationMs','samples','sampledMs','activeSampledMs']})
    for field,total in sums.items():
        for row in record[field]: total[row['frame']]+=row['sampledMs']
result={'timingComparable':False,'classification':'diagnostic-attribution-only','profileCount':len(profiles),'profiles':profiles}
result.update({field:sorted([{'frame':key,'sampledMs':value} for key,value in total.items()],key=lambda item:-item['sampledMs']) for field,total in sums.items()})
(root/'aggregate.json').write_text(json.dumps(result,indent=2)+'\n')
for field,total in sums.items():
    print(field)
    for key,value in sorted(total.items(),key=lambda item:-item[1]):
        if any(term in key for term in ['Fold','foldState','Scheduler','schedule','publish','emit','report','slice','refreshHiddenInput']): print(round(value,3),key)
