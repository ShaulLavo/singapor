from pathlib import Path
root=Path('/work/projects/Editor/examples/stress')
original=(root/'first-paint.mjs').read_text()
for arm in ['baseline','optimized']:
 source=original
 def replace(before,after):
  global source
  assert source.count(before)==1,(before,source.count(before))
  source=source.replace(before,after)
 replace("from '@playwright/test'","from 'file:///work/projects/Editor/node_modules/.bun/@playwright+test@1.63.0/node_modules/@playwright/test/index.mjs'")
 replace("from 'vite'","from 'file:///work/projects/Editor/node_modules/.bun/vite@8.0.16+d3f314a9d3c46eac/node_modules/vite/dist/node/index.js'")
 for module in ['core-package.mjs','fixtures.mjs','errors.mjs','scenarios.mjs','src/fallbackFixture.ts','src/fixtures.ts']:
  replace("from './"+module+"'","from '"+str(root/module)+"'")
 replace("const root = dirname(fileURLToPath(import.meta.url))", "const root = '/work/projects/Editor/examples/stress'\nconst profileDirectory = '/work/tmp/editor-e034-completion/first-text-profile-"+arm+"'\nawait mkdir(profileDirectory, { recursive: true })")
 replace("const temporaryDirectory = await mkdtemp('/work/tmp/editor-first-paint-')","const temporaryDirectory = profileDirectory")
 replace("    worker: { format: 'es' },", """    worker: { format: 'es' },
    plugins: [{
      name: 'frozen-core-profile-source-maps', enforce: 'pre',
      async load(id) {
        if (!id.includes('/dist/') || !id.endsWith('.js')) return null
        const code = await readFile(id, 'utf8')
        if (!code.includes('//# sourceMappingURL=')) return null
        return { code, map: JSON.parse(await readFile(`${id}.map`, 'utf8')) }
      },
      transform(code, id) {
        if (id !== resolve(root, 'src/firstPaint.ts')) return null
        let marked = code.replace('start = performance.now()', "start = performance.now(); performance.mark('e034-profile.open.start')")
        marked = marked.replace('const created = createEditorTextBuffer(source)', "performance.mark('e034-profile.buffer.start'); const created = createEditorTextBuffer(source); performance.mark('e034-profile.buffer.end')")
        marked = marked.replace('onInitialPaint: (event) => paints.push({ ...event, at: performance.now() })', "onInitialPaint: (event) => { if (event.phase === 'text') performance.mark('e034-profile.first-text'); paints.push({ ...event, at: performance.now() }) }")
        if (marked === code || !marked.includes("performance.mark('e034-profile.first-text')")) fail('Missing profile markers')
        return { code: marked, map: null }
      },
    }],""")
 replace("      emptyOutDir: true,","      emptyOutDir: true,\n      minify: false,\n      sourcemap: true,")
 replace("    suite: 'first-paint',","    suite: 'e034-first-text-cpu-profile',\n    budgetEligible: false,")
 replace("      states: ['cold', 'warm'],","      states: ['warm'],\n      profiling: { mode: 'cdp-cpu-and-user-timing', intervalMicros: 100, minify: false, timingComparable: false, window: 'profile-mark-open-start-through-profile-mark-first-text', laterInput: false },")
 replace("      sourceHash,","      sourceHash,\n      sourceHashScope: 'point-in-time-inventory; frozen-core-and-bundle-hashes-are-the-executed-artifact',\n      runnerSource: fileURLToPath(import.meta.url),\n      runnerHash: createHash('sha256').update(await readFile(fileURLToPath(import.meta.url))).digest('hex'),")
 replace("const expected = fixtures.length * plugins.length * modes.length * 2 * repetitions","const expected = fixtures.length * plugins.length * modes.length * result.config.states.length * repetitions")
 replace("  if (sourceHash !== (await hashBenchmarkSource(repository, files, core.sourceDirectory)))\n    fail('Measured sources changed during the run')","  if (result.environment.coreBuildHash !== await hashDirectory(resolve(core.directory, 'dist'))) fail('Frozen core build changed')\n  if (result.environment.bundleHash !== await hashDirectory(directory)) fail('Profile bundle changed')")
 replace("  await rm(temporaryDirectory, { recursive: true, force: true })","  await rm(browserDirectory, { recursive: true, force: true })")
 replace("    const timing = await page.evaluate(() => __firstPaint.open())","    const timing = await profileOpen(session, identity)")
 replace("    const fallback = result.config.fallbackCases\n      ? await fallbackCases(session, identity, result)\n      : null","    const fallback = null")
 replace("  const expectedRevision = values['fallback-cases'] ? 36 : 0","  const expectedRevision = 0")
 source += """
async function profileOpen({ page, cdp }, identity) {
  if (identity.repetition < 0) return page.evaluate(() => __firstPaint.open())
  const traceEvents = []
  const collect = ({ value }) => traceEvents.push(...value)
  cdp.on('Tracing.dataCollected', collect)
  await cdp.send('Tracing.start', { traceConfig: { recordMode: 'recordUntilFull', includedCategories: ['blink.user_timing'] } })
  await cdp.send('Profiler.enable')
  await cdp.send('Profiler.setSamplingInterval', { interval: 100 })
  await cdp.send('Profiler.start')
  const timing = await page.evaluate(() => __firstPaint.open())
  const { profile } = await cdp.send('Profiler.stop')
  await cdp.send('Profiler.disable')
  const complete = new Promise((accept) => cdp.once('Tracing.tracingComplete', accept))
  await cdp.send('Tracing.end')
  const status = await complete
  cdp.off('Tracing.dataCollected', collect)
  if (status.dataLossOccurred) fail('Profile trace lost events')
  const marks = traceEvents.filter((event) => event.name.startsWith('e034-profile.'))
  const stamp = (name) => {
    const events = marks.filter((event) => event.name === name)
    if (events.length !== 1) fail(`Expected one profile mark: ${name}, got ${events.length}`)
    return events[0].ts
  }
  const start = stamp('e034-profile.open.start')
  const end = stamp('e034-profile.first-text')
  if (!(profile.startTime <= start && start < end && end <= profile.endTime)) fail('CPU and marker clocks disagree')
  const name = `${identity.mode}-warm-${identity.repetition}`
  await writeFile(resolve(profileDirectory, `${name}.raw-profile.json`), JSON.stringify(profile) + '\\n')
  await writeFile(resolve(profileDirectory, `${name}.trace.json`), JSON.stringify({ traceEvents, marks, window: { start, end } }) + '\\n')
  const trimmed = trimProfile(profile, start, end)
  await writeFile(resolve(profileDirectory, `${name}.cpuprofile`), JSON.stringify(trimmed) + '\\n')
  if (identity.mode === 'direct') {
    const bufferStart = stamp('e034-profile.buffer.start')
    const bufferEnd = stamp('e034-profile.buffer.end')
    await writeFile(resolve(profileDirectory, `${name}-buffer.cpuprofile`), JSON.stringify(trimProfile(profile, bufferStart, bufferEnd)) + '\\n')
    await writeFile(resolve(profileDirectory, `${name}-after-buffer.cpuprofile`), JSON.stringify(trimProfile(profile, bufferEnd, end)) + '\\n')
  }
  return { ...timing, profile: name, profileWindowMicros: { start, end } }
}
function trimProfile(profile, start, end) {
  let time = profile.startTime
  let previous = start
  const samples = [], timeDeltas = []
  for (const [index, id] of profile.samples.entries()) {
    time += profile.timeDeltas[index]
    if (time < start || time > end) continue
    samples.push(id)
    timeDeltas.push(time - previous)
    previous = time
  }
  if (samples.length === 0) fail('No CPU samples in profile window')
  return { ...profile, startTime: start, endTime: end, samples, timeDeltas }
}
"""
 Path('/work/tmp/editor-e034-completion/first-text-profile-'+arm+'.mjs').write_text(source)
