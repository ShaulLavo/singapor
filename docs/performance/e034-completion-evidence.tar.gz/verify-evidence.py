import hashlib
import json
import sys
import tarfile
from pathlib import Path

archive = Path(sys.argv[1])
output = Path(sys.argv[2])
output.mkdir(parents=True, exist_ok=False)
with tarfile.open(archive, 'r:gz') as source:
    source.extractall(output, filter='data')
manifest = json.loads((output / 'artifacts-manifest.json').read_text())
for name, expected in manifest['files'].items():
    path = output / name
    assert path.is_file(), f'Missing artifact: {name}'
    assert path.stat().st_size == expected['bytes'], f'Size mismatch: {name}'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected['sha256'], f'Hash mismatch: {name}'
print(json.dumps({'archive': str(archive), 'extracted': str(output), 'verifiedFiles': len(manifest['files']), 'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest()}))
