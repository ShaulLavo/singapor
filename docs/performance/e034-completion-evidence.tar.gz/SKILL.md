# E034 completion

Work in /work/projects/Editor. User authorized completing plans/e034-snapshot-indentation-folds.md.
Read AGENTS.md and applicable skills. Preserve all existing E001 and backlog edits.

Acceptance: exact fold/undo/shared-view/prepared behavior; zero fallback-attributed full-text
materialization; unchanged-region reuse; bounded background work; reduced repeated work without
p95 input or first-text regression. Cold discovery/preparation and explicit commands are separate.

Root owns benchmark execution, result artifacts, docs, and inventory changes. Do not run browser
timings or expensive builds/tests unless root coordinates them. Do not modify files unless assigned.
Never start a server. Use existing structured logs and real built-package benchmark evidence.
Review controls before claims; retain all results. Do not choose thresholds after seeing candidate
results, relabel callback times as physical paint, or mask an unresolved regression as completion.

Send concise findings with source paths and a concrete next step. Keep research/prototypes under
/work/tmp/editor-e034-completion so benchmark source hashes cannot drift during captures.
