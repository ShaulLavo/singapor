import type { FoldRange } from '/work/projects/Editor/packages/editor/src/syntax/session'
import type { VirtualizedFoldMarker } from '/work/projects/Editor/packages/editor/src/virtualization/virtualizedTextViewTypes'
import type { IndentationFoldIndex } from '/work/projects/Editor/packages/editor/src/editor/indentationFoldIndex'
import {
  foldMarkerFromRange,
  foldRangeKey,
} from '/work/projects/Editor/packages/editor/src/editor/folds'

export type FoldMarkerSource = {
  readonly size: number
  readRows(rows: readonly number[]): ReadonlyMap<number, VirtualizedFoldMarker>
  all(): readonly VirtualizedFoldMarker[]
}

type RowRun = { start: number; end: number }

function requestedRowRuns(rows: readonly number[]): RowRun[] {
  const ordered = [...new Set(rows)].toSorted((left, right) => left - right)
  const runs: RowRun[] = []
  for (const row of ordered) {
    const previous = runs.at(-1)
    if (previous && previous.end + 1 === row) {
      previous.end = row
      continue
    }
    runs.push({ start: row, end: row })
  }
  return runs
}

export function readIndexedMarkers(
  index: IndentationFoldIndex | null,
  contributed: readonly FoldRange[],
  collapsedKeys: ReadonlySet<string>,
  rows: readonly number[],
): ReadonlyMap<number, VirtualizedFoldMarker> {
  const requested = new Set(rows)
  const nearest = new Map<number, FoldRange>()
  for (const run of requestedRowRuns(rows)) {
    const folds = index?.headers(run.start, run.end) ?? []
    for (const fold of folds) adoptNearest(nearest, fold)
  }
  for (const fold of contributed) {
    if (!requested.has(fold.startLine)) continue
    adoptNearest(nearest, fold)
  }
  const markers = new Map<number, VirtualizedFoldMarker>()
  for (const [row, fold] of nearest) {
    markers.set(row, foldMarkerFromRange(fold, collapsedKeys.has(foldRangeKey(fold))))
  }
  return markers
}

function adoptNearest(nearest: Map<number, FoldRange>, fold: FoldRange): void {
  const previous = nearest.get(fold.startLine)
  if (previous && previous.endLine <= fold.endLine) return
  nearest.set(fold.startLine, fold)
}
