import gzip
import hashlib
import json
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parent
destination = Path('/work/projects/Editor/docs/performance/e034-completion-evidence.tar.gz')
suffixes = {'.json', '.jsonl', '.log', '.png', '.patch', '.md', '.txt', '.py', '.mjs', '.ts'}
files = {path for path in root.iterdir() if path.is_file() and path.suffix in suffixes}
for generated in ['artifacts-manifest.json', 'archive-summary.json', 'archive-verification.json']:
    files.discard(root / generated)
files.add(root / 'comparator-probes/report.json')

directories = ['final', 'acceptance', 'isolated', 'confirmation', 'input-profile-baseline',
               'input-profile-initial', 'first-text-profile-baseline', 'first-text-profile-optimized',
               'direct-input-profile-candidate', 'direct-input-profile-baseline']
for name in directories:
    for path in (root / name).rglob('*'):
        relative = path.relative_to(root / name)
        if any(part in {'build', 'browser', 'node_modules'} for part in relative.parts):
            continue
        if path.is_file() and path.suffix in suffixes | {'.cpuprofile'}:
            files.add(path)

for path in (root / 'profile-support').rglob('*'):
    if path.is_file() and path.suffix in {'.json', '.js', '.map'}:
        files.add(path)

required = ['isolated-design.json', 'isolated-analysis.json', 'isolated-costs.json',
            'confirmation-design.json', 'confirmation-analysis.json', 'confirmation-costs.json',
            'confirmation-protocol.json', 'confirmation-core-proof.json',
            'confirmation-bundle-proof.json', 'final-core-proof.json',
            'benchmark-source.patch', 'benchmark-source-isolated.patch',
            'completion-diagnostic.json', 'candidate-acceptance.patch', 'replay-notes.md',
            'direct-input-profile-candidate.mjs', 'direct-input-profile-baseline.mjs',
            'direct-input-profile-common.mjs',
            'direct-input-profile-analysis.mjs', 'direct-input-profile-analysis.json',
            'direct-input-profile-findings.md', 'profile-support/manifest.json']
for name in required:
    assert root / name in files, f'Missing final artifact: {name}'


def capture_paths(directory, blocks):
    return {root / directory / f'block-{block:02d}-{arm}.json'
            for block in range(1, blocks + 1) for arm in ['baseline', 'control', 'candidate']}


for directory, blocks in [('isolated', 12), ('confirmation', 24)]:
    expected = capture_paths(directory, blocks)
    actual = set((root / directory).glob('block-*.json'))
    assert actual == expected, f'{directory} requires exactly {blocks * 3} named captures'
    assert expected <= files, f'{directory} captures missing from archive inventory'

confirmation = json.loads((root / 'confirmation-design.json').read_text())
protocol = json.loads((root / 'confirmation-protocol.json').read_text())
assert hashlib.sha256((root / 'confirmation-design.json').read_bytes()).hexdigest() == protocol['designSha256']
assert confirmation['purpose'] == 'final'
assert len(confirmation['blocks']) == 24, 'Confirmation requires 24 predeclared blocks'
declared = {root / block[arm] for block in confirmation['blocks']
            for arm in ['baseline', 'control', 'candidate']}
assert declared == capture_paths('confirmation', 24), 'Confirmation paths must use fresh captures'

support = json.loads((root / 'profile-support/manifest.json').read_text())
for name in ['direct-input-profile-candidate', 'direct-input-profile-baseline']:
    assert root / name / 'result.json' in files, f'Missing {name} result'
    assert len(list((root / name).glob('*.cpuprofile'))) == 15, f'Missing {name} CPU profiles'
    assert len(list((root / name).glob('*.events.json'))) == 15, f'Missing {name} event windows'
    entries = support['profiles'][name]['files']
    assert support['profiles'][name]['cpuProfileCount'] == 15
    assert len(entries) == 2 and {Path(entry['path']).suffix for entry in entries} == {'.js', '.map'}
    for entry in entries:
        path = root / entry['path']
        assert path in files, f'Missing profile support: {path}'
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256']

manifest = {
    'files': {str(path.relative_to(root)): {
        'bytes': path.stat().st_size,
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    } for path in sorted(files)},
    'experiments': {'isolated': {'blocks': 12, 'captures': 36, 'role': 'historical unresolved'},
                    'confirmation': {'blocks': 24, 'captures': 72, 'role': 'completed unresolved confirmation'}},
    'excluded': ['Frozen package and benchmark worktree directories',
                 'Full profile Vite build directories; consumed direct-input bundles/maps are in profile-support',
                 'Chromium temporary profile directories', 'Synthetic comparator-probe inputs'],
}
manifest_path = root / 'artifacts-manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
files.add(manifest_path)

def neutral_metadata(info):
    info.uid = info.gid = info.mtime = 0
    info.uname = info.gname = ''
    info.mode = 0o644
    return info

with destination.open('xb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for path in sorted(files):
                archive.add(path, arcname=str(path.relative_to(root)), recursive=False,
                            filter=neutral_metadata)
print(json.dumps({'archive': str(destination), 'files': len(files),
                  'bytes': destination.stat().st_size,
                  'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
