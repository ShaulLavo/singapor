from pathlib import Path
root = Path('/work/projects/Editor/examples/stress')
source = (root / 'first-paint.mjs').read_text()
def replace(before, after):
    global source
    assert source.count(before) == 1, (before, source.count(before))
    source = source.replace(before, after)
replace("from '@playwright/test'", "from 'file:///work/projects/Editor/node_modules/.bun/@playwright+test@1.63.0/node_modules/@playwright/test/index.mjs'")
replace("from 'vite'", "from 'file:///work/projects/Editor/node_modules/.bun/vite@8.0.16+d3f314a9d3c46eac/node_modules/vite/dist/node/index.js'")
for module in ['core-package.mjs', 'fixtures.mjs', 'errors.mjs', 'scenarios.mjs', 'src/fallbackFixture.ts', 'src/fixtures.ts']:
    replace("from './" + module + "'", "from '" + str(root / module) + "'")
replace("const root = dirname(fileURLToPath(import.meta.url))", "const root = '/work/projects/Editor/examples/stress'\nconst profileDirectory = '/work/tmp/editor-e034-completion/input-profile-initial'\nawait mkdir(profileDirectory, { recursive: true })")
replace("const directory = await mkdtemp('/work/tmp/editor-first-paint-')", "const directory = resolve(profileDirectory, 'build')\nawait mkdir(directory, { recursive: true })")
replace("    worker: { format: 'es' },", """    worker: { format: 'es' },
    plugins: [{
      name: 'frozen-core-profile-source-maps',
      enforce: 'pre',
      async load(id) {
        if (!id.includes('/dist/') || !id.endsWith('.js')) return null
        const code = await readFile(id, 'utf8')
        if (!code.includes('//# sourceMappingURL=')) return null
        const map = JSON.parse(await readFile(`${id}.map`, 'utf8'))
        return { code, map }
      },
    }],""")
replace("      emptyOutDir: true,", "      emptyOutDir: true,\n      minify: false,\n      sourcemap: true,")
replace("    suite: 'first-paint',", "    suite: 'e034-fallback-input-cpu-profile',\n    budgetEligible: false,")
replace("      states: ['cold', 'warm'],", "      states: ['warm'],\n      profiling: { mode: 'cdp-cpu', intervalMicros: 100, minify: false, timingComparable: false, window: 'each-real-12-key-burst-after-beginEditBurst-through-next-frame', editorDiagnostics: values.diagnostics },")
replace("      sourceHash,", "      sourceHash,\n      runnerSource: fileURLToPath(import.meta.url),\n      runnerHash: createHash('sha256').update(await readFile(fileURLToPath(import.meta.url))).digest('hex'),")
replace("const expected = fixtures.length * plugins.length * modes.length * 2 * repetitions", "const expected = fixtures.length * plugins.length * modes.length * result.config.states.length * repetitions")
replace("  await rm(directory, { recursive: true, force: true })", "  // Keep profiling build and maps for independent stack attribution.")
replace("""    await page.keyboard.type('xxxxxxxxxxxx', { delay: 16 })
    await page.evaluate(() => new Promise(requestAnimationFrame))
    bursts.push(await page.evaluate(() => __firstPaint.finishEditBurst()))""", """    const profiling = identity.state === 'warm' && identity.mode === 'prepared' && identity.repetition >= 0
    if (profiling) {
      await cdp.send('Profiler.enable')
      await cdp.send('Profiler.setSamplingInterval', { interval: 100 })
      await cdp.send('Profiler.start')
    }
    await page.keyboard.type('xxxxxxxxxxxx', { delay: 16 })
    await page.evaluate(() => new Promise(requestAnimationFrame))
    const burst = await page.evaluate(() => __firstPaint.finishEditBurst())
    if (profiling) {
      const { profile } = await cdp.send('Profiler.stop')
      await cdp.send('Profiler.disable')
      const name = `warm-prepared-${identity.repetition}-burst-${index}.cpuprofile`
      await writeFile(resolve(profileDirectory, name), JSON.stringify(profile) + '\\n')
      burst.cpuProfile = name
    }
    bursts.push(burst)""")
output = Path('/work/tmp/editor-e034-completion/first-paint-profile.mjs')
output.write_text(source)
print(output)
