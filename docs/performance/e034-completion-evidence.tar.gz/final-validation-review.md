E034 remains open. The fixed 24-block confirmation completed, but only seven of eight primary upper bounds pass. Prepared-warm input is unresolved: candidate p95 is 0.9000000059604645 ms against pooled controls at 1 ms, with bounds [-0.09999999403953552, +0.09999999403953552] ms. Its upper bound exceeds the unchanged 1e-7 ms numerical epsilon. This is neither a demonstrated primary regression nor evidence sufficient for acceptance.

Independent replay through the frozen analyzer matched [confirmation-analysis.json](confirmation-analysis.json) exactly. Review also verified:

- All 72 distinct raw captures, 1,440 recorded documents and 51,840 input events. Each arm/group contains 120 documents and 4,320 input events; no earlier-study capture is included.
- All six arm orders occur four times. The 144 capture start/finish events form a sequential successful timeline; every capture follows both declaration timestamps and every recorded run timestamp falls within its capture.
- The protocol's SHA-256 of the design file and the analysis's canonical design hash match. The declared 24 blocks, seed 60061, 32,768 bootstrap draws, eight primary endpoints, alpha 0.05, zero margin and numerical epsilon are unchanged.
- Raw correctness, event ordering, fixture identity, configuration, browser/runtime/hardware/affinity and cleanup pass the validator. The clock grid is 0.1 ms in all 72 captures. No primary baseline/control drift is detected; this is not proof of equality.
- Source/core/bundle identities are constant within each arm; baseline and unchanged control match. Current isolated sources and frozen core dist hashes match the captures. Core and recorded bundle hashes also match the earlier isolated study. The expected source-hash difference between studies includes the declared block-count tooling change. No bundle was rebuilt during this review. Full identities are recorded in [confirmation-bundle-proof.json](confirmation-bundle-proof.json).
- All 96 fields in [confirmation-costs.json](confirmation-costs.json) match direct extraction from the raw observations.

Primary results below use rounded milliseconds for readability. The gate uses the original raw values.

| Group | Input p95 candidate / controls | Input difference upper bound | Text callback p95 candidate / controls | Text difference upper bound |
|---|---:|---:|---:|---:|
| Direct cold | 1.4 / 1.5 | 0 | 21.5 / 58.6 | -36.3 |
| Direct warm | 0.9 / 1.0 | 0 | 8.9 / 39.2 | -29.6 |
| Prepared cold | 1.5 / 1.5 | 0 | 11.8 / 18.6 | -6.7 |
| Prepared warm | 0.9 / 1.0 | +0.1 | 3.1 / 8.5 | -5.2 |

The secondary results contain material costs. Cold input-to-requestAnimationFrame p95 increases from 10.7 to 15.0 ms for direct attachment, difference bounds [+4.1, +4.5] ms, and from 10.7 to 14.5 ms for prepared attachment, bounds [+3.5, +4.1] ms. Warm frame p95 improves by 3.6 and 3.1 ms. Screenshot-completion upper-bound p95 improves in every group. These frame/capture observables include browser scheduling and capture effects; they are neither editor-only causal timings nor proof of physical presentation. Their regressions remain reportable even though they are outside the primary gate.

Setup and explicit-command costs must remain separate from text callbacks. Prepared setup p95 is 153.1 ms cold and 144.0 ms warm, against baseline/control 122.1–122.3 and 102.1–102.3 ms. Preparation includes buffer creation and awaiting ready fallback metadata before the callback clock starts; do not add the separately reported buffer duration again. Direct synchronous first-fold p95 is 127.1 ms cold and 120.0 ms warm, against 83.2 and 69.3–69.4 ms. Fold-all p95 also increases, approximately 9.3–9.4 versus 6.4 ms cold and 8.0–8.1 versus 5.2–5.3 ms warm.

Memory summaries are forced-GC Runtime.getHeapUsage usedSize plus backingStorageSize, not fold-only retained bytes or total process memory. Initial candidate p95 is approximately 41.8–45.7 MB versus controls 23.3–27.1 MB; after edits it is 57.8–60.8 MB versus 53.9–56.9 MB. Production timing runs cannot themselves prove zero fallback-attributed materialization because diagnostics are disabled; the separate diagnostic evidence remains necessary.

The earlier 12-block study remains independently unresolved. Its prepared-warm pass cannot be combined with this study's direct-warm pass: all eight bounds must pass within one declared study. The two reports retain separate nominal 95% bound families, with finite cluster-bootstrap and quantized-tail limitations; there is no joint 95% coverage claim. Follow the [confirmation protocol](confirmation-protocol.json): no additional unchanged-candidate captures after this inconclusive result. Preserve both studies and keep the E034 plan open.

This review ran no browser, build, profile or repository test workload and changed no repository source.
