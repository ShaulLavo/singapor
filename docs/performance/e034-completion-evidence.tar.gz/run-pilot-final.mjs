import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { createWriteStream } from 'node:fs'
import { readFile, writeFile } from 'node:fs/promises'

const root = '/work/tmp/editor-e034-completion'
const runs = [
  ['baseline', 'baseline'],
  ['control', 'baseline'],
  ['candidate', 'candidate-final'],
]
const timeline = []
for (const [name, core] of runs) {
  const args = ['-c', '8,10,12,14', 'node', 'examples/stress/first-paint.mjs',
    '--core-directory', `${root}/${core}`, '--repetitions', '5', '--fixtures', 'short-lines',
    '--plugins', 'none', '--modes', 'direct,prepared', '--fallback-cases',
    '--output', `${root}/pilot-final-${name}.json`]
  const entry = { name, args, startedAt: new Date().toISOString(), pressureBefore: await readFile('/proc/pressure/cpu', 'utf8') }
  console.log(JSON.stringify({ event: 'pilot.start', name, at: entry.startedAt }))
  const output = createWriteStream(`${root}/pilot-final-${name}.log`, { flags: 'wx' })
  const process = spawn('taskset', args, { cwd: '/work/projects/Editor', stdio: ['ignore', 'pipe', 'pipe'] })
  process.stdout.pipe(output, { end: false })
  process.stderr.pipe(output, { end: false })
  const code = await new Promise((resolve, reject) => {
    process.on('error', reject)
    process.on('close', resolve)
  })
  output.end()
  timeline.push({ ...entry, code, endedAt: new Date().toISOString(), pressureAfter: await readFile('/proc/pressure/cpu', 'utf8') })
  await writeFile(`${root}/pilot-final-timeline.json`, JSON.stringify(timeline, null, 2) + '\n')
  assert.equal(code, 0, `${name} failed; inspect its structured log`)
  console.log(JSON.stringify({ event: 'pilot.complete', name }))
}
