# Batch visible fold markers once per row update

This is a source-reviewed internal API proposal. The companion TypeScript file is an
unexecuted prototype. No repository source, builds, tests or browser timings changed.

## Current call path

Prepared attachment enters `Editor.attachSession` at
`packages/editor/src/editor/Editor.ts:1702` and calls `renderPreparedDocument` inside
`view.runAtomicRender`. `view.setText` marks the pending render. Then
`installPreparedFallbackFolds` adopts the prepared index and publishes a marker source.
`VirtualizedTextView.setIndexedFoldState`, currently line 689, sees the pending atomic
render and leaves the visible-row key invalidated. The outer atomic render flushes once.

`VirtualizedTextView.renderSnapshot` calls `renderRows`, currently
`virtualizedTextViewRows.ts:171`. That creates one `RowUpdatePass`, then reconciles each
virtual item. `rowUpdateState` asks `foldMarkerByStartRow.get(bufferRow)` for every primary
document row. That object is actually `FoldMarkerSource` on the indexed path.

`EditorFoldState.markerSource().get` calls `indexedMarkerAtRow`, which calls
`IndentationFoldIndex.headers(row, row)`. Each call locates the same fact block twice,
scans its accepted fold candidates, resolves candidate positions, constructs matching
`FoldRange` objects and then one `VirtualizedFoldMarker`. Neighboring viewport rows repeat
the same block lookup and candidate filtering. A warm row reconciliation can ask twice:
`isRowCurrent` uses `foldMarkerForVirtualRow`, followed by `mountedRowUpdateState`.

These are source paths, not measured call counts. Other attachment selection/layout passes
can also refresh rows; the proposal batches each such pass separately.

## Contract

Replace `FoldMarkerSource.get(row)` with
`readRows(rows: readonly number[]): ReadonlyMap<number, VirtualizedFoldMarker>`.
Keep `size` and the existing explicit `all()` getter. A call contains only primary document
rows the caller is about to update. Duplicates are allowed, so wrapped display rows are safe.
The result contains at most one marker per distinct requested source row.

The source merges consecutive requested rows into runs and calls the existing
`IndentationFoldIndex.headers(start, end)` once per run. It selects the shortest ending fold
for each header and preserves the current equal-range precedence: indexed fold first,
then the first matching contributed fold. Contributed folds are scanned once per pass.

For a contiguous prepared viewport this is one bounded range query. Folded views require
separate runs. A single min/max range is invalid: twenty mounted rows can span hundreds of
thousands of hidden source rows. No hidden gap is part of the query. Wrapping continuations,
injected rows and diff-only rows must be excluded before requesting markers, following the
existing `isDocumentTextDisplayRow && sourceStartColumn === 0` condition.

This uses the existing index unchanged. It neither enumerates all folds nor introduces a
cache with invalidation rules. The result belongs to one row update pass and is then released.

## Complete consumer migration

1. `virtualization/foldMarkerSource.ts`: replace the point query with `readRows`.
2. `editor/foldState.ts`: replace `indexedMarkerAtRow` with the batch selection helper in
   `marker-pass-prototype.ts`. `markerSource` still captures one immutable index, contributed
   range list and collapsed-key set; `all` keeps its current explicit enumeration behavior.
3. `virtualization/virtualizedTextViewInternals.ts`: restore `foldMarkerByStartRow` to an
   actual readonly map for the ordinary array path. Keep `foldMarkerSource` separately.
4. `VirtualizedTextView.setIndexedFoldState`: assign the source and clear the ordinary marker
   map instead of assigning the source as a map-shaped substitute.
5. `virtualizedTextViewLayout.setFoldStateLayout`: its empty-marker early return currently
   relies on the substitute map's size. After separating it, require `foldMarkerSource === null`
   before taking that early return. Otherwise clearing indexed folds silently preserves them.
6. `virtualizedTextViewRows.ts`: make `RowUpdatePass` hold the concrete marker map. The pass
   builder receives the actual rows being updated, derives their primary buffer rows, and calls
   `readRows` once. For the ordinary array path, reuse its existing marker map directly.
   `rowUpdateState`, `mountedRowUpdateState`, and `isRowCurrent` all use the pass map. Pass the
   existing update pass into `isRowCurrent` and remove its independent point-query helper.

The four pass-producing flows are `renderRows`, `updateMountedRowsAfterSameLineEdit`,
`updateMountedFoldMarkers`, and `refreshCursorLineRows`. The first two use `virtualItems`;
the third uses mounted rows. Cursor-line refresh should first collect only the mounted rows
accepted by `shouldRefreshCursorLineRow`, then build a pass over that small set. Remove
`refreshCursorLineGutterCells`' default pass constructor, since its single caller already
supplies one. This avoids querying the entire viewport on ordinary caret movement.

There are no additional `FoldMarkerSource` consumers in the source inventory. `setFoldMap`
reuses the source through `setIndexedFoldState`; `getState().foldMarkers` invokes `all()`
only when explicitly read. Same-line/multi-line marker projection applies to ordinary marker
arrays and remains separate. `packages/gutters/src/foldGutter.ts` reads each supplied
`EditorGutterRowContext.foldMarker` and requires no changes.

## Verification targets

- Extend the existing atomic indexed-marker case in
  `packages/editor/test/virtualizedTextView.test.ts:456` to use `readRows`, verify the control
  still appears when the virtual row window is unchanged, and confirm its click target.
- In a focused real-index view case, record `headers` arguments during initial prepared paint.
  One contiguous pass should request one visible run, not one request per source row.
  Keep `all()` instrumented so implicit whole-index enumeration fails the check.
- Collapse a region covering most of a large document, with dense nested fold headers inside
  it. Verify requested runs exclude the hidden gap and returned marker count is bounded by
  primary mounted rows. This catches the tempting but unbounded min/max optimization.
- Verify mixed wraps and injected/diff rows show a marker only on the first actual source row;
  repeated buffer rows must not duplicate marker work or create injected-row controls.
- Cover duplicate starts across index/manual contributions and equal end-line ties, preserving
  existing shortest-fold precedence and collapse callbacks.
- Clear an indexed source with `setFoldState([], null)` and verify both markers and source are
  released. Also replace the document and the prepared generation to catch stale pass results.
- Preserve a same-line edit's DOM node and collapse state while updating the marker offsets.
  Cursor movement should read only affected mounted rows and leave unrelated gutter cells alone.
- Use the existing prepared-document and shared-view suites after implementation to prove each
  view queries its own viewport and collapse state while sharing an immutable prepared index.

Browser timings remain root-owned. The proposal removes repeated tree work, but its map and
requested-row preparation also cost time. A matched build must show whether it improves first
text before accepting this change as a performance fix.
