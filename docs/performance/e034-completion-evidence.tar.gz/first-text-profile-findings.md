# E034 first-text CPU profile

This is diagnostic attribution only. It does not establish acceptance or reproduce the production p95 difference.

## What ran

The scratch runners use the real stress entry and 500,000-line fixture with frozen `baseline` and `candidate-optimized` built packages. Each variant has five direct warm documents and five prepared warm documents after one unrecorded warmup per group. Chromium ran sequentially with CPU affinity `8,10,12,14`. No server was started.

Both variants use the same unminified build, source-map handling and 100-microsecond CDP CPU sampling. A temporary Vite transform inserts performance marks at opening, buffer construction and the first text callback. CDP user-timing timestamps bound the CPU samples precisely. Later input, screenshots, expected-text materialization and disposal are outside the analyzed windows.

The result metadata sets `budgetEligible: false` and `timingComparable: false`. It records the runner, frozen core and executed browser bundle hashes. Source inventories are labeled point-in-time because the workspace was being edited independently. The frozen core and executed bundle are checked again at completion.

## Main finding

The prepared first-text profile has no dominant new fallback call. Both variants defer the complete piece-buffer line index until the first positional lookup. E034 changes which caller triggers that common work.

The baseline builds the index while adopting prepared folds:

`attachSession → renderPreparedDocument → installPreparedFallbackFolds → adoptFolds → foldCommandLocations → offsetToPoint → bufferLineIndex`

The optimized candidate builds it when the prepared atomic render flushes:

`attachSession → flushAtomicRender → renderSnapshot → refreshMetrics → projection row lookup → bufferLineIndex`

The candidate's `refreshMetrics` inclusive total therefore includes the line-index construction. It is not evidence that viewport measurement itself became a 30 ms operation.

| Prepared interval, totals over five documents | Baseline | Optimized |
|---|---:|---:|
| Opening through first text callback, marked wall time | 41.591 ms | 40.280 ms |
| `bufferLineIndex`, inclusive sampled time | 23.492 ms | 24.641 ms |
| `extendBufferLineIndex`, self plus descendants | 20.470 ms | 21.942 ms |
| `renderPreparedDocument`, inclusive sampled time | 28.422 ms | 1.694 ms |
| `installPreparedFallbackFolds`, inclusive sampled time | 26.779 ms | No sampled hits |

The prepared fallback adoption improvement mostly moves the first full buffer-index construction to a later consumer on the same pre-callback path. The indexed folds do not eliminate that shared document-index cost.

## Direct opening is mostly buffer creation

| Direct interval, totals over five documents | Baseline | Optimized |
|---|---:|---:|
| Opening through first text callback | 174.427 ms | 178.175 ms |
| Marked immutable-buffer creation | 135.536 ms | 141.297 ms |
| Buffer share of first-text interval | 77.70% | 79.30% |
| After buffer creation through callback | 38.615 ms | 36.623 ms |
| `scanLineTerminators`, self sampled time | 114.413 ms | 119.354 ms |
| Initial `countLineBreaks`, self sampled time | 14.262 ms | 13.794 ms |

The frozen variants have byte-identical `src/pieceTable/lineEndings.ts`, `src/pieceTable/buffers.ts` and `src/documentSession.ts`. Buffer construction is common work. It is inside direct first-text timing and outside prepared first-text timing.

A second full scan then occurs when the first rendered row needs the piece buffer's positional index. For direct opening, `bufferLineIndex` accounts for 23.458 ms sampled inclusive time in the baseline and 21.334 ms in the optimized candidate across five documents.

## Source and next step

- `candidate-optimized/src/pieceTable/buffers.ts:162` calls `extendBufferLineIndex` whenever the indexed prefix is shorter than the entire text.
- `candidate-optimized/src/pieceTable/buffers.ts:203` scans every remaining newline, even if the caller only requested the first visible line.
- `candidate-optimized/src/pieceTable/buffers.ts:225` grows and copies the typed offset array while building the index.
- `candidate-optimized/src/virtualization/virtualizedTextView.ts:1292` calls `refreshMetrics` when the viewport first becomes visible; the resulting render needs positional lookups.
- `candidate-optimized/src/editor/Editor.ts:1867` installs prepared text and folds before that atomic flush.
- `candidate-optimized/src/pieceTable/lineEndings.ts:58` scans the input's terminators during the immutable buffer's initial construction.

This profile does not attribute the unresolved production prepared p95 shift of +0.6 ms to a specific new operation. It shows that removing more prepared-fold publication work is unlikely to remove the dominant first-text cost.

A narrowly targeted first-text improvement would address the full piece-buffer positional index on the first visible-row lookup. For prepared documents, completing or transferring that index during preparation would move this known cost before attachment. A more structural solution would index only the needed prefix or share the line facts already discovered during preparation. Either choice needs explicit cold/preparation accounting. Optimizing the common text-normalization scan would improve direct open, but would not explain an E034-specific prepared regression.

## Reproduction and retained evidence

These are the recorded commands. A rerun must use fresh profiling directories in new copies of the runners so the retained captures are preserved.

```sh
taskset -c 8,10,12,14 node /work/tmp/editor-e034-completion/first-text-profile-baseline.mjs --core-directory /work/tmp/editor-e034-completion/baseline --repetitions 5 --fixtures short-lines --plugins none --modes direct,prepared --fallback-cases --output /work/tmp/editor-e034-completion/first-text-profile-baseline/result.json
taskset -c 8,10,12,14 node /work/tmp/editor-e034-completion/first-text-profile-optimized.mjs --core-directory /work/tmp/editor-e034-completion/candidate-optimized --repetitions 5 --fixtures short-lines --plugins none --modes direct,prepared --fallback-cases --output /work/tmp/editor-e034-completion/first-text-profile-optimized/result.json
python /work/tmp/editor-e034-completion/first-text-profile-order.py
node /work/tmp/editor-e034-completion/profile-summary-all.mjs /work/tmp/editor-e034-completion/first-text-profile-baseline
node /work/tmp/editor-e034-completion/profile-summary-all.mjs /work/tmp/editor-e034-completion/first-text-profile-optimized
python /work/tmp/editor-e034-completion/first-text-profile-aggregate.py
```

The two `first-text-profile-*/` directories retain results, build/maps, raw profiles, traces, callback-bounded profiles and separate direct-buffer/post-buffer profiles. `first-text-profile-aggregate.json` contains all aggregated stack totals.

CDP emitted 13 out-of-order sample deltas, with a largest backward step of 70 microseconds. The raw profiles are unchanged. The normalization script reconstructs absolute timestamps, stably sorts samples, trims them to the recorded marks, and reconstructs nonnegative deltas. Each directory has `sample-order.json` describing those changes. This is another reason to use these profiles for call-path attribution rather than production timing claims.
