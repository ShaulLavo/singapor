from pathlib import Path
import json
for arm in ['baseline','optimized']:
 root=Path('/work/tmp/editor-e034-completion/first-text-profile-'+arm)
 records=[]
 for p in root.glob('*.raw-profile.json'):
  raw=json.loads(p.read_text()); trace=json.loads(p.with_name(p.name.replace('.raw-profile.json','.trace.json')).read_text())
  marks={x['name']:x['ts'] for x in trace['marks']}
  time=raw['startTime'];samples=[]
  for i,(node,delta) in enumerate(zip(raw['samples'],raw['timeDeltas'])):
   time+=delta;samples.append((time,i,node))
  samples.sort()
  name=p.name.replace('.raw-profile.json','')
  windows={'':(marks['e034-profile.open.start'],marks['e034-profile.first-text'])}
  if name.startswith('direct'):
   windows['-buffer']=(marks['e034-profile.buffer.start'],marks['e034-profile.buffer.end'])
   windows['-after-buffer']=(marks['e034-profile.buffer.end'],marks['e034-profile.first-text'])
  for suffix,(start,end) in windows.items():
   selected=[x for x in samples if start<=x[0]<=end]
   previous=start;deltas=[]
   for timestamp,index,node in selected:deltas.append(timestamp-previous);previous=timestamp
   assert len(selected)>0 and min(deltas)>=0
   output={**raw,'startTime':start,'endTime':end,'samples':[x[2] for x in selected],'timeDeltas':deltas}
   (root/(name+suffix+'.cpuprofile')).write_text(json.dumps(output)+'\n')
  records.append({'file':p.name,'rawNegativeDeltaCount':sum(d<0 for d in raw['timeDeltas']),'maximumBackwardMicros':max([-d for d in raw['timeDeltas'] if d<0],default=0)})
 (root/'sample-order.json').write_text(json.dumps({'normalization':'Recover absolute sample timestamps by cumulative raw deltas, stably sort chronologically, trim to recorded performance marks, then reconstruct nonnegative deltas. No raw profiles changed.','profiles':records},indent=2)+'\n')
