import { generateFallbackFixture } from '/work/projects/Editor/examples/stress/src/fallbackFixture.ts'
import { createPieceTableSnapshot } from '/work/projects/Editor/packages/editor/src/pieceTable/snapshot.ts'
const text = generateFallbackFixture('short-lines', 60061)
const snapshot = createPieceTableSnapshot(text, { normalized: true })
const index = snapshot.buffers.lineIndexes?.get(snapshot.buffers.original)
console.log(JSON.stringify({ fixture: 'short-lines', seed: 60061, textCodeUnits: text.length, lineBreaks: snapshot.root?.subtreeLineBreaks, indexedLineBreaks: index?.count, indexedCodeUnits: index?.scannedLength, capacity: index?.offsets.length, retainedOffsetBytes: index?.offsets.byteLength, originalTextShared: index?.text === text }))
