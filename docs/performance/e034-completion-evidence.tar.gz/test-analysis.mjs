import assert from 'node:assert/strict'
import { writeFile } from 'node:fs/promises'
import { analyze, primaryMetrics, secondaryMetrics, readResult, validateRun, validateExperiment } from './analysis.mjs'

const root = '/work/projects/Editor/docs/performance/'
const baseline = await readResult(root + 'e034-before.json.gz')
const control = await readResult(root + 'e034-control.json.gz')
const candidate = await readResult(root + 'e034-after.json.gz')
const checks = []
const valid = (name, run) => { validateRun(run); checks.push({ name, passed: true }) }
valid('checked baseline', baseline)
valid('checked control', control)
valid('checked candidate', candidate)

function rejects(name, mutate) {
  const run = structuredClone(baseline)
  mutate(run)
  assert.throws(() => validateRun(run))
  checks.push({ name, passed: true })
}
rejects('empty samples', (run) => { run.samples = [] })
rejects('missing sample', (run) => { run.samples.pop() })
rejects('duplicate sample', (run) => { run.samples[1] = structuredClone(run.samples[0]) })
rejects('sample hash mismatch', (run) => { run.samples[0].fixtureHash = '0'.repeat(64) })
rejects('missing input event', (run) => { run.samples[0].fallback.bursts[0].events.pop() })
rejects('invalid input clock', (run) => { run.samples[0].fallback.bursts[0].events[0].appliedAt = -1 })
rejects('null input clock', (run) => { run.samples[0].fallback.bursts[0].events[0].appliedAt = null })
rejects('missing memory snapshot', (run) => { delete run.samples[0].fallback.initialHeap })
rejects('retained document', (run) => { run.samples[0].cleanup.retainedObjects = 1 })
rejects('blank screenshot', (run) => { run.samples[0].pixels.text.ink = 0 })
rejects('missing callback metric', (run) => { delete run.samples[0].latencyMs.textCallback })
rejects('unobserved callback timestamp', (run) => { run.samples[0].latencyMs.textCallback += 100 })

const orders = [
  ['baseline', 'control', 'candidate'], ['control', 'candidate', 'baseline'], ['candidate', 'baseline', 'control'],
  ['candidate', 'control', 'baseline'], ['control', 'baseline', 'candidate'], ['baseline', 'candidate', 'control'],
]
const design = {
  schemaVersion: 1, purpose: 'final', predeclaredAt: '2020-01-01T00:00:00.000Z', seed: 60061,
  bootstrapDraws: 2000, familywiseAlpha: 0.05, clockQuantumMs: 0.1, numericalEpsilonMs: 1e-7, regressionMarginMs: 0,
  primaryMetrics, secondaryMetrics,
}
function syntheticBlocks() {
  return Array.from({ length: 12 }, (_, index) => {
    const order = orders[index % orders.length]
    const block = { id: `block-${index}`, order }
    for (const [position, arm] of order.entries()) {
      block[arm] = structuredClone(baseline)
      block[arm].id = `${index}-${arm}`
      block[arm].createdAt = new Date(Date.UTC(2021, 0, 1, index, position)).toISOString()
    }
    return block
  })
}
function slow(run, duration = 25) {
  for (const sample of run.samples) {
    sample.latencyMs.textCallback += duration
    sample.latencyMs.visibleTextUpperBound += duration
    sample.observation.paints.find((paint) => paint.phase === 'text').at += duration
    for (const burst of sample.fallback.bursts) delayEvents(burst.events, duration)
  }
}
function delayEvents(events, duration) {
  for (const event of events) { event.appliedAt += duration; event.frameAt += duration }
}
const sameData = syntheticBlocks()
assert.equal(analyze(design, sameData).acceptance.passed, true)
checks.push({ name: 'synthetic identical block data passes strict bound', passed: true })
const equality = syntheticBlocks()
for (const block of equality) slow(block.candidate, 3e-8)
const equalityReport = analyze(design, equality)
assert.equal(equalityReport.acceptance.passed, true)
assert.ok(equalityReport.metrics.some((metric) => metric.upperMs > 0 && metric.upperMs < 1e-7))
checks.push({ name: 'strict equality tolerates only numerical subtraction residue and retains raw bounds', passed: true })
const slower = syntheticBlocks()
for (const block of slower) slow(block.candidate)
const slowdown = analyze(design, slower)
assert.equal(slowdown.acceptance.status, 'regression')
assert.ok(slowdown.metrics.filter((metric) => metric.family === 'primary').every((metric) => metric.lowerMs > 24))
checks.push({ name: 'synthetic 25 ms candidate slowdown detected', passed: true })
const drift = syntheticBlocks()
for (const block of drift) slow(block.control)
assert.equal(analyze(design, drift).acceptance.status, 'invalid-control-drift')
checks.push({ name: 'control drift prevents candidate acceptance', passed: true })
const environmentMismatch = syntheticBlocks()
environmentMismatch[0].candidate.environment.browser = 'other-browser'
assert.throws(() => validateExperiment(design, environmentMismatch), /environment mismatch/)
checks.push({ name: 'different browser rejected', passed: true })
const hardwareMismatch = syntheticBlocks()
hardwareMismatch[0].candidate.environment.hardware.cpu = 'other-cpu'
assert.throws(() => validateExperiment(design, hardwareMismatch), /environment mismatch/)
checks.push({ name: 'different hardware rejected', passed: true })
const differentControl = syntheticBlocks()
differentControl[0].control.environment.coreBuildHash = '0'.repeat(64)
assert.throws(() => validateExperiment(design, differentControl), /unchanged control/)
checks.push({ name: 'changed control build rejected', passed: true })
const pilot = analyze({ ...design, purpose: 'pilot' }, [{ id: 'pilot', order: orders[0], baseline, control, candidate }])
assert.equal(pilot.acceptance.status, 'pilot-only')
assert.equal(pilot.boundsAvailable, false)
assert.ok(pilot.metrics.every((metric) => metric.upperMs === null))
checks.push({ name: 'one browser block cannot produce uncertainty bounds', passed: true })
const report = { note: 'Validator uses checked raw E034 artifacts. Statistical tests clone them into explicitly synthetic blocks; they are not measured browser evidence.', checks }
await writeFile('/work/tmp/editor-e034-completion/analysis-tests.json', JSON.stringify(report, null, 2) + '\n')
await writeFile('/work/tmp/editor-e034-completion/historical-pilot-summary.json', JSON.stringify(pilot, null, 2) + '\n')
console.log(JSON.stringify({ passed: checks.length, tests: '/work/tmp/editor-e034-completion/analysis-tests.json' }))
