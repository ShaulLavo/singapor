import copy
import gzip
import json
import subprocess
from pathlib import Path

repository = Path('/work/projects/Editor')
output = Path('/work/tmp/editor-e034-completion/comparator-probes')
output.mkdir(exist_ok=True)
baseline = json.loads(gzip.decompress((repository / 'docs/performance/e034-before.json.gz').read_bytes()))
base = output / 'baseline.json'
base.write_text(json.dumps(baseline))

def mutate(name, callback):
    value = copy.deepcopy(baseline)
    callback(value)
    path = output / (name + '.json')
    path.write_text(json.dumps(value))
    completed = subprocess.run(['node', str(repository / 'examples/stress/fallback-compare.mjs'), str(base), str(path)], capture_output=True, text=True)
    return {'case':name, 'accepted':completed.returncode == 0, 'exitCode':completed.returncode, 'error':completed.stderr[:240]}

probes = [
    mutate('all-samples-missing', lambda result: result.update(samples=[])),
    mutate('one-sample-missing', lambda result: result['samples'].pop()),
    mutate('duplicate-sample', lambda result: result['samples'].__setitem__(1, copy.deepcopy(result['samples'][0]))),
    mutate('different-browser', lambda result: result['environment'].update(browser='999.0.0.0')),
    mutate('different-hardware', lambda result: result['environment']['hardware'].update(cpu='other CPU')),
    mutate('wrong-sample-hash', lambda result: result['samples'][0].update(fixtureHash='0' * 64)),
    mutate('missing-input-event', lambda result: result['samples'][0]['fallback']['bursts'][0]['events'].pop()),
    mutate('negative-input-latency', lambda result: result['samples'][0]['fallback']['bursts'][0]['events'][0].update(appliedAt=-100)),
    mutate('leaked-document', lambda result: result['samples'][0]['cleanup'].update(retainedObjects=1)),
]
(output / 'report.json').write_text(json.dumps(probes, indent=2) + '\n')
print(json.dumps(probes, indent=2))
