# E034 direct warm input diagnostic

The fresh profiles do not establish a remaining structural latency regression. They show a small
amount of avoidable offset-geometry maintenance in the candidate, but do not connect it to the
unresolved production p95 bound in the historical isolated study. That study had seven of eight
primary gates passing, with direct/warm input unresolved at a +0.2 ms upper bound. The later
24-block confirmation also remains unresolved: prepared/warm input has a +0.1 ms upper bound,
while direct/warm input passes within that separate study. Neither the profiles nor endpoint
passes selected across the two studies establish final acceptance.

## Capture validation

Both arms use the isolated `benchmark-worktree` at `4146ab67`, the final frozen candidate or
`88cd55d` baseline core build, and the same browser benchmark instrumentation. Their source and
core build hashes match the final isolated block-12 artifacts. Runtime, Chromium, hardware, CPU
affinity (`8,10,12,14`), helper hash, and original/transformed browser source hashes match across
arms. Later changes in the live Editor checkout are outside both captured dependency trees.

Each arm contains all five measured warm documents after one unrecorded warmup, three bursts per
document, and twelve real inputs per burst: 15 profiles, 180 trusted events, and 360 matching
beforeinput/onChange marks. All documents have the expected final revision and release their
retained objects. All event windows fit inside their profiles. CDP NavigationStart alignment
checks pass; every saved selection exactly matches the raw samples inside its recorded event
window. Neither arm has negative sample deltas or a `finishEditBurst` frame in any profile.

The copied runner awaits `Profiler.stop` before calling `finishEditBurst`, excluding its
expected-full-string reconstruction. Raw profiles are unchanged. The analysis counts samples
inside half-open beforeinput/onChange intervals and uses source maps for core stack locations.
It does not infer duration weights or allocation bytes from sample counts.

## Matched observations

| Observation | Candidate | Baseline |
| --- | ---: | ---: |
| Sum of the 180 diagnostic input intervals | 142.4 ms | 143.6 ms |
| Diagnostic p50 | 0.8 ms | 0.8 ms |
| Diagnostic p95 | 1.2 ms | 1.1 ms |
| Largest diagnostic input interval | 1.7 ms | 1.8 ms |
| Inputs above 1.1 ms | 10 | 9 |
| CPU samples inside input intervals | 915 | 920 |
| Hidden-input refresh, inclusive samples | 272 | 270 |
| Same-line view update, inclusive samples | 307 | 262 |
| Fallback controller update, inclusive samples | 43 | 0 |
| Index constructor, inclusive samples | 7 | 0 |
| Index adoption (`blocks.slice` path), inclusive samples | 3 | 0 |
| `replaceFacts`, inclusive samples | 5 | 0 |
| Fold projection validation, inclusive samples | 0 | 36 |
| Crossing-range rejection, inclusive samples | 0 | 40 |
| Work scheduler, inclusive samples | 10 | 29 |
| Garbage collector, self samples | 2 | 5 |

Inclusive rows overlap and must not be added. The candidate still adds synchronous index
maintenance to same-line rendering, while removing the baseline's projection validation,
crossing-range rejection, and part of its scheduling work. Hidden-input refresh remains the
largest individual sampled function and is almost identical between arms. The candidate has no
sampled index `position` calls in these input windows, consistent with the earlier endpoint-reuse
change removing that work.

The geometry-maintenance paths contribute eight distinct samples: three under `adopt` and five
under `replaceFacts`, or 0.87% of the candidate's selected samples. The latter include two tree
update samples, one offset-block construction sample, and one semantic comparison sample. That
comparison would still be required by a topology-only design. There is another fact-block
construction sample in the reader's staging path. These counts establish that the work exists;
they do not support attributing a 0.2 ms p95 shift to it or predict the benefit of removing it.

## Early inputs and GC

| Document | Candidate total input ms | Baseline total input ms | Candidate inputs >1.1 ms | Baseline inputs >1.1 ms |
| --- | ---: | ---: | ---: | ---: |
| 1 | 29.7 | 30.2 | 2 | 2 |
| 2 | 28.7 | 28.7 | 3 | 2 |
| 3 | 29.2 | 27.7 | 1 | 2 |
| 4 | 27.6 | 29.5 | 3 | 2 |
| 5 | 27.2 | 27.5 | 1 | 1 |

Eight of the candidate's ten slower events occur in the first two keys of a document's first
burst; all nine baseline events above 1.1 ms occupy those positions. The first document's first
two keys take 1.6/1.7 ms in the candidate and 1.6/1.8 ms in the baseline. Candidate key 1 has one
fallback sample; key 2 has none. Their other samples are distributed through existing buffer,
row rendering, selection, and hidden-input work. This does not isolate a candidate-only early
cost, and absence of a sample is not proof that a short function did not execute.

The candidate's two GC samples occur on 0.8 ms and 0.7 ms events, away from its slowest inputs.
The baseline has five GC samples across four events. There is no sampled GC explanation for the
candidate's slower tail. Excluding `finishEditBurst` from a CPU window does not prove that later
GC excludes objects allocated before that window or during a prior burst.

## Decision

A row-topology-only index remains a coherent structural improvement: remove duplicated line
lengths and prefix offsets, resolve absolute fold endpoints through the generation's existing
TextSnapshot, and share blocks/tree/directory when affected rows retain their indentation and
region markers. This would also remove the roughly 3,907-entry vector copy per ordinary edit
for the 500,000-line fixture. The correctness contract requires rereading changed rows,
immutable previous generations, generation-local absolute-range caches, exact LF/EOF endpoints,
and normal propagation for semantic or line-count changes.

That work is justified as removing document-size-dependent metadata maintenance, if pursued for
that purpose. The measured CPU target here is small. These profiles do not justify presenting it
as a demonstrated repair for the unresolved p95 bound. It also trades maintenance for snapshot
lookups during fold queries, so any implementation must measure ordinary input, explicit fold
commands, gutter queries, and retained memory against the current candidate.

This is one instrumented Chromium process per arm, each containing dependent warm documents and
keystrokes. Unminified bundles, User Timing marks, profiler startup, and 100-microsecond requested
sampling perturb execution. Browser timestamp quantization limits event-boundary attribution;
actual sample spacing is not assumed to equal the requested interval. CPU samples cannot
establish allocation volume or an allocation regression. The full production experiment remains
the acceptance evidence.

## Artifacts

- `direct-input-profile-candidate/` and `direct-input-profile-baseline/`: results, raw profiles,
  per-event selections, instrumented browser source, bundles, and source maps.
- `direct-input-profile-analysis.mjs`: reproducible validation and aggregation.
- `direct-input-profile-analysis.json`: complete per-event data, inclusive/self counts, and stacks.
- `direct-input-profile-analysis-summary.jsonl`: compact machine-readable summaries.
