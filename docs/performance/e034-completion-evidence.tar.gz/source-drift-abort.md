# Shared-workspace source drift

`acceptance-design.json` was declared at 17:22:51 UTC on 2026-09-12. Five captures completed under
`acceptance/`: all three arms in block 1, followed by block 2 control and candidate. All five
passed individual validation with consistent per-arm hashes and matching unchanged-control hashes.

Block 2 baseline completed its workload but failed the end-of-run source check at 17:30:06 UTC.
Concurrent edits changed `packages/lsp-plugin/src/codeActions.ts`, `plugin.ts`, and `serverSet.ts`,
and added `workspaceEditProvenance.ts`. Their modification times fell within that capture. Those
three existing files are included in the declared source hash even though this no-language workload
does not use the LSP plugin. The new companion file was not in the initial hash list.
`source-drift-attribution.json` records the observed modification times and their evidentiary limit;
the guard itself proves an aggregate source change. The guard remained enabled and rejected the run.

No completed result JSON was written for the failed capture. Its first-text sample log and two
screenshots are preserved; full input-event records were held in process memory and were not
written after the failed source check. The failed attempt is excluded because the instrument
rejected source identity, not because of observed latency.

The five valid records are preserved separately and do not enter the restarted comparison.
The live LSP edits were preserved. The benchmark moves to a detached checkout pinned to the same
commit, with the benchmark changes overlaid and workspace runtime outputs copied. External package
dependencies may be shared; source files and workspace package outputs are isolated.
