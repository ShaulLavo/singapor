# E034 warm prepared input profile

These are diagnostic CPU profiles, not production timing evidence. The copied runners build the real stress entry with the frozen core package, retain source maps, and use the real 500,000-line fixture and native keyboard input. No server was started and no repository files were changed.

## Artifacts and method

- Candidate runner: `/work/tmp/editor-e034-completion/first-paint-profile.mjs`.
- Baseline runner: `/work/tmp/editor-e034-completion/first-paint-profile-baseline.mjs`.
- Each group has five warm prepared samples after one unrecorded warmup, three twelve-key bursts per sample, and 15 CPU profiles covering 180 input events.
- CPU affinity is `8,10,12,14`; Chromium is headless; the build is unminified with source maps; CDP sampling interval is 100 microseconds. Editor performance diagnostics stay disabled.
- Both result files identify the suite as `e034-fallback-input-cpu-profile`, set `budgetEligible: false`, and mark timings incomparable to production.
- Results, build, maps, CPU profiles and aggregate stacks live in `input-profile-initial/` and `input-profile-baseline/` beside this report. Each result records the frozen core build hash, fixture hash and copied runner hash.
- `aggregate.json` has every sampled stack. Inclusive totals count descendants and cannot be added indiscriminately.
- Profiling starts after `beginEditBurst` and ends after the next animation frame and `finishEditBurst`. Cold fold commands, preparation and screenshot verification are outside the window.

## Findings

| Stack | Candidate sampled ms | Baseline sampled ms | Meaning |
|---|---:|---:|---|
| Input operation, inclusive | 160.274 | 160.118 | Overall sampled input work is similar; these samples do not independently prove the production p95 shift. |
| `applySameLineEdit`, inclusive | 53.925 | 43.096 | Candidate adds synchronous fallback maintenance in the edit render path. |
| Fallback controller `update`, inclusive | 8.035 | absent | About 44.6 sampled microseconds per key. It includes construction, row-fact reads, persistent tree update and publication. |
| Index `step`, inclusive | 5.886 | absent | Bounded discovery is still synchronous in ordinary input when the small edit can finish immediately. |
| Index `replaceFacts`, inclusive | 3.052 | absent | Its tree update uses `compareLines` and repeatedly resolves global positions. |
| Index `position`, self | 3.047 | absent | Position lookup is a visible new cost. `compareLines` contributes 2.439 ms inclusive beneath tree rebuilding. |
| Work scheduler `schedule`, inclusive | 7.204 | 2.358 | Added scheduling is measurable. Candidate fallback `scheduleSlice` alone costs 5.098 ms inclusive. |
| Fallback `report`, inclusive | 0.153 | absent | Diagnostic/log object creation is present even with diagnostics disabled, but sampled time is small. |
| Fallback `publish`, inclusive | 0.308 | absent | Publication is not the dominant sampled new cost. |
| `refreshHiddenInputContent`, inclusive | 47.333 | 47.371 | This large existing DOM/input cost is essentially identical and does not explain E034. |
| Garbage collector, self | 29.998 | 2.650 | The window includes benchmark-owned full-string reconstruction; this is not sufficient evidence of an editor allocation regression. |

The direct `previous.blocks.slice()` at candidate `src/editor/indentationFoldIndex.ts:359` has no sampled hits in `adopt` or the builtin slice. The entire constructor has 0.613 ms inclusive. This run does not support treating the array copy as the main source of elapsed input work. It also cannot exclude allocation effects that appear later during garbage collection.

The baseline still spends 8.688 ms validating fold projection sets and 7.578 ms rejecting crossing ranges. Candidate removes those repeated paths. This accounts for why the total sampled input operation remains similar while its local edit rendering is more expensive.

## Concrete source paths

- `candidate-initial/src/editor/fallbackFoldController.ts:74`: `update` constructs an index and immediately runs one slice.
- `candidate-initial/src/editor/fallbackFoldController.ts:95`: `schedule` republishes the current index and schedules work even when that index already matches the document. The scheduled callback then discovers that no work is required.
- `candidate-initial/src/editor/fallbackFoldController.ts:208`: `report` constructs diagnostics and calls the supplied logger.
- `candidate-initial/src/editor/indentationFoldIndex.ts:449`: `replaceFacts` path-copies the index tree and calls its position-based comparator.
- `candidate-initial/src/editor/indentationFoldIndex.ts:727`: `position` looks up a fact owner and walks the block tree to resolve its document row.
- `candidate-initial/src/editor/Editor.ts:549`: the fallback controller always receives a logging callback, whose eventual logger may have no consumer.
- `/work/projects/Editor/examples/stress/src/firstPaint.ts:254`: `finishEditBurst` reconstructs the benchmark's full expected source string after all twelve inputs. That allocation must be outside any future GC attribution window.

## Next step

Avoid scheduling fallback work when the current ready index already matches the document. Keep logging work conditional on an actual observer. Then rerun the unchanged production workload to determine whether the p95 gap remains.

If it remains, profile that corrected artifact with CPU sampling stopped before `finishEditBurst`. Use an allocation profile to test whether index generations contribute meaningful allocation. Investigate position resolution in tree rebuilding before assuming that the direct array copy dominates.
