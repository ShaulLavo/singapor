import json, math, statistics
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

root=Path('/work/tmp/editor-e034-completion')
report=json.loads((root/'isolated-analysis.json').read_text())
primary=next(row for row in report['metrics'] if row['group']=='short-lines/direct/none/warm' and row['metric']=='inputApplied')
epsilon=report['numericalEpsilonMs']
def quantile(values,fraction):
    ordered=sorted(values)
    return ordered[max(0,math.ceil(len(ordered)*fraction)-1)]
def summary(events):
    values=[event['appliedLatencyMs'] for event in events]
    return {'events':len(values),'meanMs':statistics.mean(values),'p50Ms':quantile(values,.5),'p90Ms':quantile(values,.9),'p95Ms':quantile(values,.95),'p99Ms':quantile(values,.99),'maxMs':max(values),'aboveReferenceP95':sum(value>primary['referenceP95Ms']+epsilon for value in values),'above1_1Ms':sum(value>1.1+epsilon for value in values),'above1_2Ms':sum(value>1.2+epsilon for value in values),'clockBinCountsForDisplayOnly':dict(sorted(Counter(f'{value:.1f}' for value in values).items(),key=lambda item:float(item[0])))}
def pressure(text):
    return {line.split()[0]:{field.split('=')[0]:float(field.split('=')[1]) for field in line.split()[1:]} for line in text.splitlines()}
def wall(at):
    return datetime.fromisoformat(at.replace('Z','+00:00'))
timeline=defaultdict(dict)
for line in (root/'isolated-design.json.timeline.jsonl').read_text().splitlines():
    event=json.loads(line)
    timeline[(event['block'],event['arm'])][event['event']]=event
all_events=[]
runs=[]
for block in json.loads((root/'isolated-design.json').read_text())['blocks']:
    for arm in ['baseline','control','candidate']:
        path=root/block[arm]
        run=json.loads(path.read_text())
        events=[]
        documents=[]
        for sample in run['samples']:
            if sample['mode']!='direct' or sample['state']!='warm':continue
            document_events=[]
            bursts=[]
            for burst_index,burst in enumerate(sample['fallback']['bursts']):
                burst_events=[{'block':block['id'],'arm':arm,'repetition':sample['repetition'],'burst':burst_index,'key':key,'at':event['at'],'appliedAt':event['appliedAt'],'frameAt':event['frameAt'],'appliedLatencyMs':event['appliedAt']-event['at'],'frameLatencyMs':event['frameAt']-event['at']} for key,event in enumerate(burst['events'])]
                bursts.append({'burst':burst_index,'offset':burst['offset'],**summary(burst_events)})
                document_events.extend(burst_events)
            documents.append({'repetition':sample['repetition'],'textCallbackMs':sample['latencyMs']['textCallback'],**summary(document_events),'bursts':bursts})
            events.extend(document_events)
        boundary=timeline[(block['id'],arm)]
        start=boundary['capture.start'];finish=boundary['capture.finish']
        initial=pressure(start['cpuPressure']);final=pressure(finish['cpuPressure'])
        seconds=(wall(finish['at'])-wall(start['at'])).total_seconds()
        cpu={'start':{'at':start['at'],**initial},'finish':{'at':finish['at'],**final},'wholeCaptureSeconds':seconds,'someStallSecondsDuringWholeCapture':(final['some']['total']-initial['some']['total'])/1e6,'someStallPercentageDuringWholeCapture':(final['some']['total']-initial['some']['total'])/(seconds*1e4)}
        runs.append({'block':block['id'],'arm':arm,'orderPosition':block['order'].index(arm),'artifact':str(path.relative_to(root)),'runId':run['id'],**summary(events),'cpuPressure':cpu,'documents':documents})
        all_events.extend(events)

def grouped(field):
    return [{'arm':arm,field:value,**summary([event for event in all_events if event['arm']==arm and event[field]==value])} for arm in ['baseline','control','candidate'] for value in sorted({event[field] for event in all_events})]
result={'purpose':'exploratory-description-only','sourceAnalysis':'isolated-analysis.json','primaryEndpointUnchanged':primary,'acceptanceUnchanged':report['acceptance'],'notes':['Every recorded direct-warm input event remains included. No bootstrap, new confidence bounds, inferential family, exclusion, or acceptance-threshold change is performed here.','All five direct-warm documents in one arm share a context; block resampling preserves them together. Document/burst/key summaries are descriptive, not independent confidence estimates.','Quantiles use the same nearest-rank rule as the preregistered analyzer and retain raw milliseconds. Histogram labels round to the observed 0.1 ms grid for display only.','CPU pressure is system-wide and sampled only at capture boundaries. Total-pressure deltas span the entire capture, including build and other mode/state groups; they cannot attribute any input event to scheduler contention. Browser performance timestamps lack a captured wall-clock origin for event-level CPU-pressure alignment.'],'arms':[{'arm':arm,**summary([event for event in all_events if event['arm']==arm])} for arm in ['baseline','control','candidate']],'runs':runs,'byRepetition':grouped('repetition'),'byBurst':grouped('burst'),'byKey':grouped('key'),'eventsAboveReferenceP95':[event for event in all_events if event['appliedLatencyMs']>primary['referenceP95Ms']+epsilon]}
(root/'direct-warm-exploration.json').write_text(json.dumps(result,indent=2)+'\n')
print('ARM SUMMARY')
for arm in result['arms']:print(arm['arm'],{key:arm[key] for key in ['p95Ms','aboveReferenceP95','above1_1Ms','above1_2Ms','maxMs']})
print('RUN SUMMARY: block arm p95 above1.0 above1.1 above1.2 PSIpercent doc-p95')
for run in runs:print(run['block'],run['arm'],round(run['p95Ms'],3),run['aboveReferenceP95'],run['above1_1Ms'],run['above1_2Ms'],round(run['cpuPressure']['someStallPercentageDuringWholeCapture'],3),[round(doc['p95Ms'],3) for doc in run['documents']])
print('BY REPETITION')
for item in result['byRepetition']:print(item['arm'],item['repetition'],round(item['p95Ms'],3),item['aboveReferenceP95'],item['above1_1Ms'])
print('BY BURST')
for item in result['byBurst']:print(item['arm'],item['burst'],round(item['p95Ms'],3),item['aboveReferenceP95'],item['above1_1Ms'])
print('BY KEY CANDIDATE')
for item in result['byKey']:
    if item['arm']=='candidate':print(item['key'],round(item['p95Ms'],3),item['aboveReferenceP95'],item['above1_1Ms'])
