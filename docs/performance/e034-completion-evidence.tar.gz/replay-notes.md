# E034 completion evidence replay

The baseline source commit is `88cd55da61e895542cfe248082221cf992be74e5`. The completion candidate
is `4146ab67e84f0bdae6be3d8e8e0f718406998dc3` plus `candidate-acceptance.patch`. Public core packages
were built before capture. `candidate-acceptance-freeze.json` records matching per-file hashes for
all 198 source and 719 dist files in the live and frozen candidate directories. The captures record
source, built-core and browser-bundle hashes independently.

Extract the evidence archive into a new directory, retaining its relative paths:

```sh
mkdir /work/tmp/e034-evidence
tar -xzf /work/projects/Editor/docs/performance/e034-completion-evidence.tar.gz \
  -C /work/tmp/e034-evidence
```

The production analyzer requires the benchmark tools and the installed `evlog` dependency. A
clean checkout of the named base commit does not contain those tools. Restore them and link the
existing dependency installation for saved-data analysis:

```sh
git -C /work/projects/Editor worktree add --detach /work/tmp/e034-replay \
  4146ab67e84f0bdae6be3d8e8e0f718406998dc3
git -C /work/tmp/e034-replay apply /work/tmp/e034-evidence/benchmark-source.patch
bun install --cwd /work/tmp/e034-replay --frozen-lockfile --ignore-scripts
ln -s /work/projects/Editor/node_modules /work/tmp/e034-replay/node_modules
```

The saved-data analyzer imports `evlog` through the benchmark error helper. A new worktree
needs dependencies installed as above, or its stress `node_modules` linked to an existing
installation. Replay verification reused the frozen installation without a new download.

`benchmark-source.patch` includes the predeclared block-count support used by confirmation.
`benchmark-source-isolated.patch` preserves the earlier overlay used for the isolated experiment
and corrected direct-input profiles; use that overlay when reconstructing their exact benchmark
source identity. The saved-data analyzer can replay each declaration separately.

The candidate core overlay is separate, `candidate-acceptance.patch`. Apply it to that checkout
when rebuilding the candidate. `completion-tests.patch` restores its focused core tests. Neither
overlay is needed merely to analyze saved measurements. Build the core and the gutter package
before any new browser capture, and freeze workspace runtime outputs and links as described in
the stress README. The existing frozen baseline uses the earlier commit recorded above.

The historical isolated experiment completed all twelve blocks (36 captures). Seven of eight
primary gates passed. Direct/warm input remained unresolved: candidate and pooled-control
observed p95 were both 1.0 ms, but the simultaneous upper bound was +0.2 ms. Control-drift checks
passed. This experiment did not establish final acceptance.

Reproduce that saved analysis with:

```sh
node /work/tmp/e034-replay/examples/stress/fallback-validation.mjs \
  /work/tmp/e034-evidence/isolated-design.json \
  /work/tmp/e034-evidence/replayed-analysis.json
```

The analyzer returns a nonzero exit code if final acceptance is unresolved, regresses, or fails
validation. Compare its JSON with `isolated-analysis.json`; the seeded report is reproducible
from the saved observations. `isolated-design.json` was declared before capture and its paths
remain unchanged. The archive retains raw JSON, structured logs, screenshots and CPU-pressure
records at capture boundaries. `artifacts-manifest.json` contains per-file SHA-256 values.

`final-design.json` belongs to an earlier aborted experiment, not the completion candidate. Its
31 successful captures and failed log remain in `final/`. Read `aborted-experiment.md` and the
explicitly exploratory `aborted-analysis-design.json`/`aborted-analysis.json` for its limits.
No earlier measurement is reused by the new acceptance declaration.

`acceptance-design.json` is a second interrupted declaration. Five valid records are retained in
`acceptance/`; the sixth run failed the source guard after concurrent LSP edits in the live
workspace. Read `source-drift-abort.md` for exactly what was retained. The restarted experiment
runs from the isolated `benchmark-worktree`, with source and core hashes verified against the
previous successful captures in `benchmark-worktree-proof.json`. Workspace runtime outputs and
links are isolated; only external package dependencies are shared.

## Fresh confirmation: completed, acceptance unresolved

The fixed 24-block confirmation completed all 72 fresh captures with the unchanged candidate
core and the same declared zero-regression criterion. The design was registered at
`2026-09-12T18:39:46.132Z`. Capture exited successfully; the analyzer exited 1 because acceptance
remains unresolved. Seven of eight primary gates pass and the control-drift checks pass.
Prepared/warm input has observed candidate p95 0.9 ms versus pooled-control p95 1.0 ms, but its
simultaneous upper bound is +0.1 ms. Direct/warm input passes in this study with upper bound zero.

`confirmation-protocol.json` records the fixed sample count, design hash, stopping rule and
analysis policy. `confirmation-analysis.json` records the verdict; `confirmation-costs.json`
records the separate construction, preparation and command costs. `confirmation-core-proof.json`
and the final `final-core-proof.json` verify all 198 source and 719 built-core files against the
frozen candidate. `confirmation-bundle-proof.json` verifies unchanged core bundles and environment
against the isolated study despite the benchmark-tool source hash change.

E034 remains open. The isolated 36 captures are historical evidence, kept separate from the 72
confirmation captures. Passing endpoints from different studies are never combined into an
acceptance verdict. No further identical study of this unchanged candidate will be run.

Timing acceptance was analyzed after all 72 successful captures. Each study retains its own
nominal bound family; the separate studies do not establish joint 95% coverage. Collection-time
inspection was limited to correctness, completeness, source identity and operational failures.

Replay the completed confirmation separately:

```sh
node /work/tmp/e034-replay/examples/stress/fallback-validation.mjs \
  /work/tmp/e034-evidence/confirmation-design.json \
  /work/tmp/e034-evidence/replayed-confirmation-analysis.json
```

Both production-analysis commands are expected to exit 1 for the recorded unresolved verdicts.
Compare each generated JSON with its corresponding saved analysis; the two studies remain
separate even though the unresolved endpoint changes.

`archive-evidence.py` refuses to create the final archive until the confirmation declaration,
analysis and costs exist and all 72 named capture JSON files are present. It also requires the
historical isolated 36 files. Presence in an archive does not turn an unresolved analysis into
acceptance; read the recorded analyzer verdict.

Pilots remain separate under their original names. `candidate-core.patch` is the controller-only
optimization; `candidate-final.patch` predates the last no-consumer marker change. Only
`candidate-acceptance.patch` represents the new acceptance candidate. The final candidate pilot
uses earlier pilot controls descriptively; a later validator-only change altered the benchmark
source hash without changing the controls' browser bundle. It is not a matched final experiment.

## Diagnostic profiles

Diagnostic CPU profiles and their summaries informed implementation. They are excluded from the
production comparison. The earlier `input-profile-initial/` and `input-profile-baseline/` windows
include benchmark-owned expected-string reconstruction, so their GC samples cannot be attributed
to the Editor. First-text profiles use callback-bounded windows; their report discloses
out-of-order CDP timestamps and normalization.

The newer `direct-input-profile-candidate/` and `direct-input-profile-baseline/` captures use the
final frozen candidate and baseline against the isolated benchmark worktree. Each retains all
five warm documents, all three bursts, and all twelve trusted inputs per burst. The runner now
awaits `Profiler.stop` before `finishEditBurst` reconstructs the expected full string. Diagnostic
User Timing marks reuse the actual beforeinput and public onChange timestamps. Event sidecars
retain the checked CDP clock alignment and select CPU samples within each input interval.

Read `direct-input-profile-findings.md` for the matched observations and limitations. Sampling,
unminified bundles and the extra marks perturb execution; these results are not production
latency evidence. Excluding reconstruction from a window does not establish the origin of
objects collected by later GC, and CPU samples do not measure allocated bytes.

`profile-support/` retains only the main JavaScript bundles and maps referenced by those newer
profiles, with their original bytes and hashes. The source maps contain the core source content
needed for attribution. Full Vite build directories, Chromium temporary directories, frozen
packages and the benchmark worktree are excluded. Raw profiles, traces, summaries, copied
runners, instrumentation helper and instrumented browser source are retained. Historical profile
summaries remain available; their excluded build directories are still local under
`/work/tmp/editor-e034-completion`.

Replay the newer profile attribution directly from an extracted evidence directory:

```sh
node /work/tmp/e034-evidence/direct-input-profile-analysis.mjs /work/tmp/e034-evidence \
  /work/tmp/e034-evidence/replayed-direct-input-profile-analysis.json \
  > /work/tmp/e034-evidence/replayed-profile-summary.jsonl
cmp /work/tmp/e034-evidence/direct-input-profile-analysis.json \
  /work/tmp/e034-evidence/replayed-direct-input-profile-analysis.json
```

This script needs only Node built-ins and the saved artifacts. It uses `profile-support/` when
the original build directories are absent, checks the profiles against the saved isolated
block-12 source/core hashes, and writes a separate replayed analysis. Absolute original
capture paths remain recorded as provenance; the replay resolves the supporting artifacts inside
the supplied extracted root. The copied capture runners still name the original frozen checkout
paths and are retained as provenance, not as portable rebuild commands.

`profile-replay-proof.json` records a successful replay from a separate directory containing only
the required saved inputs and `profile-support/`, with no original build directories. Its output
is byte-identical to the saved profile analysis, and the original evidence was left unchanged.

The focused verification logs cover controller/index/folding/rendering checks and original-buffer
index ownership. `marker-verification.txt` records the final 215-test snapshot/rendering check.
`validation-review.txt` records 38 validator tests, including duplicate and reordered input events.
Core build/typecheck and React/Solid consumer typechecks pass. Synthetic validator probes are not
observations and do not enter any experiment. The current fixture's eager original offset array
occupies exactly 2 MiB; `fused-index-memory.json` records capacity, count and original-text sharing.
