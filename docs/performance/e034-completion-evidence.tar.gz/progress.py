import json
import sys
from pathlib import Path
root=Path('/work/tmp/editor-e034-completion')
timeline = root / (sys.argv[1] if len(sys.argv)>1 else 'isolated-design.json.timeline.jsonl')
design = json.loads(Path(str(timeline).removesuffix('.timeline.jsonl')).read_text())
events=[json.loads(line) for line in timeline.read_text().splitlines()]
finished=[e for e in events if e['event']=='capture.finish' and e['code']==0]
records=[json.loads(Path(e['output']).read_text()) for e in finished]
samples=[sample for record in records for sample in record['samples']]
arm_hashes={}
for event,record in zip(finished,records):
 hashes=tuple(record['environment'][name] for name in ('sourceHash','coreBuildHash','bundleHash'))
 previous=arm_hashes.setdefault(event['arm'],hashes)
 assert previous==hashes, f'Source/build drift in {event["arm"]}'
if 'baseline' in arm_hashes and 'control' in arm_hashes:
 assert arm_hashes['baseline']==arm_hashes['control'], 'Unchanged control mismatch'

print(json.dumps({'finished':len(finished),'total':len(design['blocks'])*3,'last':events[-1]['block']+'/'+events[-1]['arm'],'event':events[-1]['event'],'documents':len(samples),'inputEvents':sum(len(burst['events']) for sample in samples for burst in sample['fallback']['bursts']),'stableArmHashes':True,'correct':all(sample['correct'] for sample in samples),'retainedObjects':sum(sample['cleanup']['retainedObjects'] for sample in samples),'cpuPressure':Path('/proc/pressure/cpu').read_text().splitlines()[0]}))
