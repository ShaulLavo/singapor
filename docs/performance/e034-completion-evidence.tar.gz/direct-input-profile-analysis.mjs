import { readFile, readdir, writeFile } from 'node:fs/promises'
import { SourceMap } from 'node:module'
import { basename, dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { existsSync } from 'node:fs'
import assert from 'node:assert/strict'

const base = resolve(process.argv[2] ?? dirname(fileURLToPath(import.meta.url)))
const output = resolve(process.argv[3] ?? resolve(base, 'direct-input-profile-analysis.json'))
const summaries = {}
for (const arm of ['candidate', 'baseline']) summaries[arm] = await analyze(arm)
await writeFile(output, JSON.stringify(summaries, null, 2) + '\n')
for (const [arm, summary] of Object.entries(summaries)) {
  console.log(JSON.stringify({ arm, validation: summary.validation, total: summary.total,
    documents: summary.documents, self: summary.self.slice(0, 24),
    fallback: summary.inclusive.filter(({ frame }) => /indentationFold|fallbackFoldController|foldState/.test(frame)),
    slowest: summary.events.toSorted((a, b) => b.latencyMs - a.latencyMs).slice(0, 12)
  }))
}

async function analyze(arm) {
  const directory = resolve(base, `direct-input-profile-${arm}`)
  const result = JSON.parse(await readFile(resolve(directory, 'result.json'), 'utf8'))
  assert.equal(result.budgetEligible, false)
  assert.equal(result.config.profiling.timingComparable, false)
  assert.equal(result.samples.length, 5)
  const reference = JSON.parse(await readFile(resolve(base, 'isolated', basename(result.environment.referenceArtifact)), 'utf8'))
  assert.equal(result.environment.sourceHash, reference.environment.sourceHash)
  assert.equal(result.environment.coreBuildHash, reference.environment.coreBuildHash)
  const files = (await readdir(directory)).filter((file) => file.endsWith('.cpuprofile')).sort()
  assert.equal(files.length, 15)
  const maps = new Map()
  const self = new Map()
  const inclusive = new Map()
  const stackCounts = new Map()
  const events = []
  let negativeDeltas = 0
  let finishNodes = 0
  let outsideWindows = 0
  let minClockMarginMs = Infinity
  for (const sample of result.samples) {
    assert.equal(sample.correct, true)
    assert.equal(sample.observation.revision, 36)
    assert.equal(sample.cleanup.retainedObjects, 0)
    assert.equal(sample.cleanup.active, false)
    assert.equal(sample.fallback.bursts.length, 3)
    for (const [burstIndex, burst] of sample.fallback.bursts.entries()) {
      const expected = `warm-direct-${sample.repetition}-burst-${burstIndex}`
      assert.equal(burst.cpuProfile, `${expected}.cpuprofile`)
      assert.equal(burst.inputProfileEvents, `${expected}.events.json`)
      const profile = JSON.parse(await readFile(resolve(directory, burst.cpuProfile), 'utf8'))
      const sidecar = JSON.parse(await readFile(resolve(directory, burst.inputProfileEvents), 'utf8'))
      assert.equal(sidecar.events.length, 12)
      assert.deepEqual(sidecar.events, burst.events)
      assert.equal(sidecar.windows.length, 12)
      assert.equal(sidecar.marks.length, 24)
      assert(sidecar.clock.metricNowMs >= sidecar.clock.beforeMs - 0.25)
      assert(sidecar.clock.metricNowMs <= sidecar.clock.afterMs + 0.25)
      minClockMarginMs = Math.min(minClockMarginMs,
        sidecar.clock.metricNowMs - sidecar.clock.beforeMs,
        sidecar.clock.afterMs - sidecar.clock.metricNowMs)
      const parents = new Map()
      const locations = new Map()
      for (const node of profile.nodes) {
        locations.set(node.id, await location(node.callFrame, directory, maps))
        for (const child of node.children ?? []) parents.set(child, node.id)
        if (node.callFrame.functionName === 'finishEditBurst') finishNodes += 1
      }
      let time = profile.startTime
      const rawSamples = profile.samples.map((nodeId, index) => {
        time += profile.timeDeltas[index]
        if (profile.timeDeltas[index] < 0) negativeDeltas += 1
        return { index, nodeId, atMicros: time }
      })
      for (const [key, window] of sidecar.windows.entries()) {
        const before = sidecar.marks.filter((mark) => mark.name === 'e034-profile-beforeinput')[key]
        const applied = sidecar.marks.filter((mark) => mark.name === 'e034-profile-onChange')[key]
        assert.equal(before.detail.trusted, true)
        assert.equal(before.detail.index, key)
        assert.equal(applied.detail.index, key)
        assert.equal(before.at, burst.events[key].at)
        assert.equal(applied.at, burst.events[key].appliedAt)
        if (window.startMicros < profile.startTime || window.endMicros > profile.endTime) outsideWindows += 1
        const selected = rawSamples.filter((entry) => entry.atMicros >= window.startMicros && entry.atMicros < window.endMicros)
        assert.deepEqual(selected, window.samples)
        const eventSelf = new Map()
        const eventInclusive = new Map()
        for (const entry of selected) {
          const stack = []
          let nodeId = entry.nodeId
          while (nodeId !== undefined) {
            const frame = locations.get(nodeId)
            assert(frame)
            stack.push(frame)
            nodeId = parents.get(nodeId)
          }
          add(self, stack[0])
          add(eventSelf, stack[0])
          add(stackCounts, stack.toReversed().join(' -> '))
          for (const frame of new Set(stack)) {
            add(inclusive, frame)
            add(eventInclusive, frame)
          }
        }
        const fallbackSamples = [...eventInclusive].filter(([frame]) => /update core\/src\/editor\/fallbackFoldController/.test(frame)).reduce((sum, [, count]) => sum + count, 0)
        events.push({ document: sample.repetition + 1, burst: burstIndex + 1, key: key + 1,
          latencyMs: window.latencyMs, samples: selected.length,
          gcSamples: [...eventSelf].filter(([frame]) => frame.startsWith('(garbage collector)')).reduce((sum, [, count]) => sum + count, 0),
          fallbackSamples, self: ranked(eventSelf).slice(0, 8),
          fallback: ranked(eventInclusive).filter(({ frame }) => /fallbackFoldController|indentationFold/.test(frame)),
        })
      }
    }
  }
  assert.equal(events.length, 180)
  assert.equal(outsideWindows, 0)
  assert.equal(finishNodes, 0)
  const documents = Array.from({ length: 5 }, (_, index) => {
    const subset = events.filter((event) => event.document === index + 1)
    return { document: index + 1, ...summarizeEvents(subset), bursts: [1, 2, 3].map((burst) => ({burst, ...summarizeEvents(subset.filter((event) => event.burst === burst))})) }
  })
  return {
    budgetEligible: false, timingComparable: false, environment: result.environment,
    method: 'Count CPU samples whose absolute timestamps fall inside each actual beforeinput/onChange interval; no interpolation or sample-duration weights.',
    validation: { profiles: files.length, trustedEvents: events.length, matchingEventMarks: 360,
      outsideWindows, finishEditBurstNodes: finishNodes, negativeDeltas, minClockMarginMs,
      finalCaptureSourceAndCoreHashesMatch: true, samplesCorrectAndReleased: true },
    total: summarizeEvents(events), documents, self: ranked(self), inclusive: ranked(inclusive), stacks: ranked(stackCounts), events,
  }
}

function summarizeEvents(events) {
  const latency = events.map((event) => event.latencyMs).sort((a, b) => a - b)
  return { events: events.length, inputWindowMs: latency.reduce((sum, value) => sum + value, 0),
    p50Ms: latency[Math.ceil(latency.length * 0.5) - 1], p95Ms: latency[Math.ceil(latency.length * 0.95) - 1],
    maximumMs: latency.at(-1), above1Point1Ms: latency.filter((value) => value > 1.100001).length,
    samples: events.reduce((sum, event) => sum + event.samples, 0),
    gcSamples: events.reduce((sum, event) => sum + event.gcSamples, 0),
    fallbackSamples: events.reduce((sum, event) => sum + event.fallbackSamples, 0),
  }
}

function add(map, key) { map.set(key, (map.get(key) ?? 0) + 1) }
function ranked(map) { return [...map].sort((a, b) => b[1] - a[1]).map(([frame, samples]) => ({frame, samples})) }
async function location(frame, directory, maps) {
  const name = frame.functionName || '(anonymous)'
  if (!frame.url.startsWith('http://localhost:4173/assets/')) return `${name} ${frame.url}`.trim()
  const asset = basename(new URL(frame.url).pathname)
  if (!maps.has(asset)) {
    const original = resolve(directory, 'build/assets', `${asset}.map`)
    const support = resolve(base, 'profile-support', basename(directory), 'assets', `${asset}.map`)
    const path = existsSync(original) ? original : support
    maps.set(asset, new SourceMap(JSON.parse(await readFile(path, 'utf8'))))
  }
  const entry = maps.get(asset).findEntry(frame.lineNumber, frame.columnNumber)
  const source = (entry.originalSource ?? asset)
    .replace(/^.*\/(?:candidate-acceptance|baseline)\/src\//, 'core/src/')
    .replace(/^.*\/benchmark-worktree\//, '')
  return `${name} ${source}:${(entry.originalLine ?? frame.lineNumber) + 1}`
}
