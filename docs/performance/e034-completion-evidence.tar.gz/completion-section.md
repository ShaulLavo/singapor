Historical drafting copy for the first 12-block study. The completed confirmation is recorded in completion-report.md and confirmation-analysis.json; endpoint passes from the two studies are not combined.

## Completion validation

The isolated experiment completed all twelve blocks: 36 browser captures, 720 recorded documents,
and 25,920 input events. Seven of eight primary upper bounds meet the declared zero-regression
rule. Warm direct input has a difference interval from -0.1 to +0.2 ms, so acceptance remains
unresolved. No primary endpoint demonstrates a regression, and the unchanged controls show no
detected systematic drift. Neither result substitutes for passing all eight upper bounds.

The baseline is `88cd55da61e895542cfe248082221cf992be74e5`. The candidate is
`4146ab67e84f0bdae6be3d8e8e0f718406998dc3` with `candidate-acceptance.patch`. The evidence directory
is `/work/tmp/editor-e034-completion`. Its `isolated-design.json`, `isolated-analysis.json`, and
`candidate-acceptance-freeze.json` retain the declaration, results, and per-file source and core
build hashes. `replay-notes.md` describes the separate benchmark overlay needed to replay analysis.

### Completed comparison

All values below are milliseconds. The difference is candidate p95 minus pooled control p95.
Each group contains 60 recorded documents and 2,160 input events per arm. The input measurement
ends at `onChange`; the text callback records the public initial paint event.

| Attachment | Metric | Pooled controls p95 | Candidate p95 | Difference | Lower bound | Upper bound |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Direct, cold | Input to onChange | 1.5 | 1.5 | 0.0 | -0.1 | 0.0 |
| Direct, cold | Text callback | 58.5 | 21.5 | -37.0 | -37.5 | -36.6 |
| Direct, warm | Input to onChange | 1.0 | 1.0 | 0.0 | -0.1 | +0.2 |
| Direct, warm | Text callback | 39.0 | 9.2 | -29.8 | -30.3 | -29.3 |
| Prepared, cold | Input to onChange | 1.5 | 1.5 | 0.0 | -0.1 | 0.0 |
| Prepared, cold | Text callback | 18.7 | 12.1 | -6.6 | -8.6 | -6.2 |
| Prepared, warm | Input to onChange | 1.0 | 1.0 | 0.0 | -0.1 | 0.0 |
| Prepared, warm | Text callback | 8.6 | 3.1 | -5.5 | -6.4 | -5.3 |

Each of the twelve blocks ran baseline, unchanged control, and candidate in separate Chromium
processes. All six orders occurred twice. The analyzer used 32,768 seeded resamples of whole
paired blocks, keeping warm documents and their input events together. Bonferroni adjustment
across the eight primary endpoints gives nominal simultaneous 95% coverage for the upper bounds,
and separately for the lower bounds. These percentile-bootstrap bounds are approximate with
twelve independent blocks and a tail estimate. Individual keys are not independent experimental samples.

Acceptance requires every primary upper bound at or below zero. The fixed 1e-7 ms epsilon handles
floating-point subtraction only. The observed 0.1 ms clock grid and separate 0.2 ms quantization
envelope do not permit a latency regression. The threshold was not changed after capture.

The secondary frame-callback metric is slower in both cold groups. Direct p95 rises from 12.5 to
15.0 ms, with difference bounds +1.1 to +4.0 ms. Prepared p95 rises from 11.2 to 14.4 ms, with
bounds +1.1 to +3.8 ms. Warm direct frame callbacks improve; warm prepared frame callbacks remain
unresolved. Screenshot-completion upper bounds improve in all four groups. Frame callbacks and
screenshots include scheduling or capture delay, and neither proves physical display presentation.
These secondary measurements remain separate from the declared primary acceptance rule.

### Preparation, commands, and memory

`isolated-costs.json` records the following descriptive p95 costs in milliseconds, using 60 samples
per cell. These costs have no separate confidence bounds. Preparation includes buffer creation
and completes before the prepared attachment timer starts. Direct attachment has no preparation
stage. The input workload executes its first fold command before typing, so it measures edits of
a ready index rather than input during initial discovery.

| Attachment | Cost | Baseline p95 | Control p95 | Candidate p95 |
| --- | --- | ---: | ---: | ---: |
| Direct, cold | First fold command | 85.2 | 83.3 | 129.2 |
| Direct, cold | Fold-all | 6.4 | 6.4 | 10.4 |
| Direct, warm | First fold command | 69.1 | 69.1 | 120.0 |
| Direct, warm | Fold-all | 5.4 | 5.3 | 12.0 |
| Prepared, cold | Preparation | 125.5 | 122.4 | 153.5 |
| Prepared, cold | First fold command | 2.4 | 2.5 | 1.7 |
| Prepared, cold | Fold-all | 6.8 | 6.4 | 9.6 |
| Prepared, warm | Preparation | 101.8 | 102.4 | 142.4 |
| Prepared, warm | First fold command | 1.4 | 1.5 | 0.9 |
| Prepared, warm | Fold-all | 5.2 | 5.3 | 8.2 |

Buffer creation p95 ranges from 32.3 to 39.2 ms in the baseline groups and from 6.0 to 7.0 ms
in the candidate.
Ready preparation and direct first-command discovery still cost more, as does fold-all. The
faster attachment callback does not remove those costs.

The following cells show initial → edited memory p95 in MiB. Each sample sums JavaScript
`usedSize + backingStorageSize` after forced collection. These process-level values include
benchmark reference strings and editor storage, so they do not isolate index allocation.

| Attachment | Baseline | Control | Candidate |
| --- | ---: | ---: | ---: |
| Direct, cold | 22.17 → 51.40 | 22.17 → 51.40 | 39.84 → 55.08 |
| Direct, warm | 23.50 → 51.95 | 23.50 → 51.95 | 41.25 → 55.63 |
| Prepared, cold | 24.41 → 53.71 | 24.41 → 53.71 | 42.19 → 57.41 |
| Prepared, warm | 25.79 → 54.29 | 25.80 → 54.29 | 43.59 → 57.97 |

### Diagnostic evidence

`completion-diagnostic-proof.json` confirms that the separate gutter-enabled diagnostic capture
matches the production source, core-build, and browser-bundle hashes. Direct and prepared groups,
both cold and warm, pass exact text, fold-boundary, and disposal checks. Each group records 36 edit
events reading 36 rows, with 3,906 unchanged blocks reused per edit and 1,200 folds. Fallback
materializations, retained roots after disposal, and dropped diagnostics are all zero.

The direct groups force cold discovery through an explicit synchronous fold command. Their
maximum slice contains 35,158 metadata operations and 159 stack steps. Those command counts are
not background slice bounds. Prepared discovery runs in background slices and records maxima of
512 metadata operations and four stack steps per slice. The diagnostic timings do not enter the
production comparison. `marker-verification.txt` records the 215 passing focused tests covering
rendering, snapshots, prepared documents, and shared fold state.

### Implementation changes

The completion candidate removes repeated work from folding and first text. A compatible ready
index no longer schedules a background callback that would immediately return. Diagnostics are
read once only when a performance sink or logger consumes them. Fold publication still occurs
before scheduling is skipped, so manual projections and view-local collapse reconciliation retain
their previous ordering. Focused controller tests cover scheduler inactivity, no diagnostic reads
without a consumer, and diagnostic-only delivery.

Subtree maximum endpoints are reused when both child endpoints are unchanged. Updating those
branches no longer resolves global line positions to repeat comparisons with unchanged inputs.
Visible fold markers are queried once per consecutive run of primary document rows in an update
pass; hidden gaps and injected/wrapped continuation rows are excluded. The same map serves row
comparison and painting. Without gutters or collapsed folds, rendering skips the marker query.
Installing a gutter or collapsing a fold resumes marker queries. View-local collapse state and
the existing nearest-fold and tie selection are preserved.

The renderer's raw `mountedRows` describe markers used for painting and can contain null markers
when no gutter or collapsed fold needs them. Public `EditorViewSnapshot.visibleRows` retain semantic
fold metadata: an explicit marker read fills one shared lazy batch from the snapshot's captured
source. The captured source remains valid after later edits or disposal.

The first-text investigation also found repeated whole-document work outside fallback discovery.
LF-only text now takes the existing native terminator probe and an LF-presence check instead of
visiting every character to count a line-ending majority that cannot differ. CRLF, mixed endings,
unusual terminators and explicit fallback semantics retain their original results. Original-piece
creation gets its newline count from the existing offset-index builder, removing the independent
counting scan. Initial painting reuses that index. Index construction remains necessary and moves
into buffer creation: direct attachment pays it during creation, while prepared attachment pays it
during preparation before the attachment timer. This move alone is not an eliminated cost.

Headless buffers now retain the original index immediately. For the 500,000-line short-lines
fixture, its 499,999 offsets occupy a 524,288-entry array: exactly 2,097,152 bytes (2 MiB), plus
unmeasured object and map overhead. The original text remains shared. Rendered documents already
retained this index after their first positional read; this change makes that allocation earlier.
Append-buffer indexes remain lazy.

Diagnostic CPU profiles of the initial corrected build found 5.10 ms of fallback scheduling across
180 warm prepared inputs. The hidden-input path consumed essentially the same sampled time in the
baseline and candidate. The endpoint-reuse optimization targets the repeated position resolutions
observed in that profile. The profiles included benchmark-owned expected-string reconstruction
after input, so their garbage-collection samples cannot establish an
Editor allocation regression. Production comparisons use the same minified runner and options
across all three arms, without CPU profiling or a diagnostics sink.

### Two aborted declarations

The first declaration, `final-design.json`, started at 16:07 UTC on 2026-09-12 with the earlier
controller-only optimization. Ten complete blocks and one additional control produced 31 result
files. The next baseline run failed before document capture at 16:44:43 UTC because a Chromium
temporary file disappeared during hashing. The result files and failed log remain in `final/`.
The ten complete blocks were analyzed as exploratory evidence; all eight primary upper bounds
remained positive. The repaired runner separates Vite output from Chromium temporary files.

The second declaration, `acceptance-design.json`, started at 17:22:51 UTC. Five captures passed
before concurrent LSP edits changed hashed source files in the shared checkout. The sixth capture
finished its workload but failed the source guard at 17:30:06 UTC. Its first-text log and two
screenshots remain in `acceptance/`, but it produced no completed result JSON. The five valid
records remain separate, along with `source-drift-abort.md` and its attribution evidence.

`isolated-design.json` declared twelve fresh blocks at 17:35:07 UTC. The completed experiment used
a detached checkout with isolated workspace package outputs and dependency links. Only external
package dependencies shared the existing store. Source, core-build, and browser-bundle hashes
matched the earlier valid baseline and candidate, and the source guard remained enabled.
Neither aborted declaration nor any pilot contributes measurements to the isolated result.
