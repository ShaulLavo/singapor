from pathlib import Path
from collections import defaultdict
import json
output={}
for arm in ['baseline','optimized']:
 root=Path('/work/tmp/editor-e034-completion/first-text-profile-'+arm)
 groups={}
 for line in (root/'summary-all.jsonl').read_text().splitlines():
  r=json.loads(line)
  name=r['file']
  group='prepared' if name.startswith('prepared') else 'after-buffer' if '-after-buffer.' in name else 'buffer' if '-buffer.' in name else 'direct'
  if group not in groups:groups[group]={'self':defaultdict(float),'inclusive':defaultdict(float),'wallMs':0,'sampledMs':0,'count':0}
  target=groups[group];target['wallMs']+=r['durationMs'];target['sampledMs']+=r['sampledMs'];target['count']+=1
  for field in ['self','inclusive']:
   for entry in r[field]:target[field][entry['frame']]+=entry['sampledMs']
 for target in groups.values():
  for field in ['self','inclusive']:
   target[field]=sorted([{'frame':k,'sampledMs':v} for k,v in target[field].items()],key=lambda x:-x['sampledMs'])
 output[arm]=groups
 print(arm)
 for group,target in groups.items():
  print(group,'wallMs',round(target['wallMs'],3),'sampledMs',round(target['sampledMs'],3))
  if group not in ['prepared','after-buffer','buffer']:continue
  for field in ['self','inclusive']:
   print(field)
   for entry in target[field][:18]:print(round(entry['sampledMs'],3),entry['frame'])
Path('/work/tmp/editor-e034-completion/first-text-profile-aggregate.json').write_text(json.dumps(output,indent=2)+'\n')
