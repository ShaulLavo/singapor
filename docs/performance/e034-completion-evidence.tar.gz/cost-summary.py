import json,math,sys
from pathlib import Path
root=Path(__file__).resolve().parent
design_path=root/(sys.argv[1] if len(sys.argv)>1 else 'isolated-design.json')
design=json.loads(design_path.read_text())
groups={}
for block in design['blocks']:
    for arm in ('baseline','control','candidate'):
        run=json.loads((root/block[arm]).read_text())
        for sample in run['samples']:
            key='/'.join((arm,sample['fixture'],sample['mode'],sample['state']))
            group=groups.setdefault(key,{})
            values={name:sample['latencyMs'][name] for name in ('buffer','constructor','preparation','attach')}
            values['firstFoldCommand']=sample['fallback']['commands'][0]['durationMs']
            values['foldAll']=sample['fallback']['commands'][2]['durationMs']
            for name,source in (('initialHeapBytes','initialHeap'),('editedHeapBytes','editedHeap')):
                snapshot=sample['fallback'][source]
                values[name]=snapshot['usedSize']+snapshot['backingStorageSize']
            for name,value in values.items():
                group.setdefault(name,[]).append(value)
def summarize(values):
    values=sorted(values)
    return {'count':len(values),'p50':values[math.ceil(len(values)*.5)-1],'p95':values[math.ceil(len(values)*.95)-1],'max':values[-1]}
result={key:{name:summarize(values) for name,values in group.items()} for key,group in sorted(groups.items())}
(root/(sys.argv[2] if len(sys.argv)>2 else 'isolated-costs.json')).write_text(json.dumps(result,indent=2)+'\n')
