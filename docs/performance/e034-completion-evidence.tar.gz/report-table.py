import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
report = json.loads((root / (sys.argv[1] if len(sys.argv) > 1 else 'isolated-analysis.json')).read_text())

def number(value):
    if abs(value) <= report['numericalEpsilonMs']:
        return '0.00'
    return f'{value:.2f}'

print(json.dumps({'controls': report['controls'], 'acceptance': report['acceptance']}))
print('\n| Group | Metric | Control p95 | Candidate p95 | Difference | Upper bound |')
print('| --- | --- | ---: | ---: | ---: | ---: |')
for metric in report['metrics']:
    if metric['family'] != 'primary':
        continue
    _, mode, _, state = metric['group'].split('/')
    name = 'Input to change' if metric['metric'] == 'inputApplied' else 'First text'
    values = [number(metric[field]) for field in
              ('referenceP95Ms', 'candidateP95Ms', 'differenceMs', 'upperMs')]
    print(f'| {mode} {state} | {name} | ' + ' | '.join(values) + ' |')
